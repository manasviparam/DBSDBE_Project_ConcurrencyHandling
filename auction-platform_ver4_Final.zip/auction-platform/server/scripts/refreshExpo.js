/**
 * Expo refresh (non-destructive): npm run refresh:expo
 *
 * - Adds the venue columns to `auctions` if they don't exist yet.
 * - Makes the expo auctions LIVE NOW (start = now, status 'active'). End times stay
 *   staggered up to 16:00 IST on the expo day; if a planned end time has already passed,
 *   it is pushed to now + 30..115 minutes so the item doesn't close instantly.
 * - Deletes the stale winner rows for revived auctions (4 and 12).
 * - Applies venues from data/venues.json (blank entries are skipped).
 * - Sets realistic starting prices (INR) and scales each auction's existing bids by the
 *   same factor so history stays consistent. Skipped for auctions already at the new price.
 * - Re-times the upcoming items (3, 8, 10, 15, 19, 21) whose start has passed or is within
 *   a day, so they show as Upcoming this evening instead of "Starting now".
 * - Leaves users, watchlist, visits and pending-approval status untouched.
 */
const path = require('path');
const fs = require('fs');
const pool = require('../config/db');

const EXPO_DATE = '2026-10-03';

// auction id -> end time (all within 12:00-16:00 IST, staggered)
const ENDS = {
  23: '13:00', 2: '13:15', 18: '13:30', 11: '13:45', 7: '14:00',
  9: '14:15', 13: '14:30', 1: '14:45', 16: '15:00', 4: '15:05',
  22: '15:15', 12: '15:25', 6: '15:30', 17: '15:40', 20: '15:50',
  5: '16:00', 14: '16:00', 24: '16:00',
};

async function ensureVenueColumns() {
  const wanted = {
    venue_name: 'VARCHAR(150) NULL',
    venue_address: 'VARCHAR(300) NULL',
    venue_lat: 'DECIMAL(9,6) NULL',
    venue_lng: 'DECIMAL(9,6) NULL',
  };
  const [cols] = await pool.query(
    `SELECT COLUMN_NAME FROM information_schema.COLUMNS
     WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'auctions'`
  );
  const have = new Set(cols.map((c) => c.COLUMN_NAME));
  for (const [name, def] of Object.entries(wanted)) {
    if (!have.has(name)) {
      await pool.query(`ALTER TABLE auctions ADD COLUMN ${name} ${def}`);
      console.log(`Added column auctions.${name}`);
    }
  }
}


// Realistic starting prices in INR.
const PRICES = {
  1: 85000, 2: 9000, 3: 6500, 4: 35000, 5: 25000, 6: 45000, 7: 60000, 8: 18000, 9: 30000, 10: 350000,
  11: 20000, 12: 120000, 13: 8000, 14: 12000, 15: 15000, 16: 10000, 17: 7000, 18: 90000, 19: 3500, 20: 9000,
  21: 15000, 22: 80000, 23: 4000, 24: 40000, 25: 55000, 26: 65000, 27: 70000, 28: 12000,
};

// Upcoming items: id -> [start, end, minimum hours from now for the start]
const UPCOMING = {
  3: ['2026-10-03 16:30', '2026-10-04 16:30', 3],
  8: ['2026-10-03 17:00', '2026-10-04 17:00', 4],
  10: ['2026-10-03 17:30', '2026-10-04 17:30', 5],
  15: ['2026-10-03 18:00', '2026-10-04 18:00', 6],
  19: ['2026-10-03 18:30', '2026-10-04 18:30', 7],
  21: ['2026-10-03 19:00', '2026-10-04 19:00', 8],
};

async function applyPrices() {
  let changed = 0;
  for (const [id, price] of Object.entries(PRICES)) {
    const [[row]] = await pool.query('SELECT starting_price FROM auctions WHERE id = ?', [id]);
    if (!row || Number(row.starting_price) === price) continue; // already done: keeps new bids untouched
    const factor = price / Number(row.starting_price);
    const digits = price >= 10000 ? -2 : -1;
    await pool.query('UPDATE bids SET amount = ROUND(amount * ?, ?) WHERE auction_id = ?', [factor, digits, id]);
    await pool.query(
      `UPDATE auctions SET starting_price = ?,
         current_highest_bid = COALESCE((SELECT MAX(amount) FROM bids WHERE auction_id = ?), ?)
       WHERE id = ?`,
      [price, id, price, id]
    );
    changed++;
  }
  return changed;
}

async function retimeUpcoming() {
  for (const [id, [start, end, hours]] of Object.entries(UPCOMING)) {
    await pool.query(
      `UPDATE auctions
       SET start_time = GREATEST(?, DATE_ADD(NOW(), INTERVAL ? HOUR)),
           end_time = GREATEST(?, DATE_ADD(NOW(), INTERVAL ? HOUR))
       WHERE id = ? AND status = 'scheduled' AND start_time < DATE_ADD(NOW(), INTERVAL 1 DAY)`,
      [`${start}:00`, hours, `${end}:00`, hours + 24, id]
    );
  }

  // Safety net: any other scheduled auction (e.g. 25-28) whose start has already passed would
  // show "Starting now" forever, so push it to this evening too, staggered 30 min apart.
  const [stale] = await pool.query(
    `SELECT id FROM auctions WHERE status = 'scheduled' AND start_time <= NOW() ORDER BY id`
  );
  for (const [n, row] of stale.entries()) {
    await pool.query(
      `UPDATE auctions
       SET start_time = DATE_ADD(NOW(), INTERVAL ? MINUTE),
           end_time = DATE_ADD(NOW(), INTERVAL ? MINUTE)
       WHERE id = ?`,
      [180 + n * 30, 180 + n * 30 + 24 * 60, row.id]
    );
  }
}

async function main() {
  await ensureVenueColumns();

  const ids = Object.keys(ENDS).map(Number);
  await pool.query('DELETE FROM auction_results WHERE auction_id IN (?)', [ids]);

  // rank by planned end so the fallback keeps the same stagger
  const order = Object.keys(ENDS).sort((a, b) => (ENDS[a] + a).localeCompare(ENDS[b] + b));
  for (const [rank, id] of order.entries()) {
    await pool.query(
      `UPDATE auctions
       SET start_time = NOW(),
           end_time = GREATEST(?, DATE_ADD(NOW(), INTERVAL ? MINUTE)),
           status = 'active'
       WHERE id = ?`,
      [`${EXPO_DATE} ${ENDS[id]}:00`, 30 + rank * 5, id]
    );
  }

  const priced = await applyPrices();
  await retimeUpcoming();

  // venues
  const file = path.join(__dirname, '..', 'data', 'venues.json');
  let applied = 0;
  if (fs.existsSync(file)) {
    const venues = JSON.parse(fs.readFileSync(file, 'utf8'));
    for (const [id, v] of Object.entries(venues)) {
      if (id.startsWith('_')) continue;
      if (!v.venue_name && !v.venue_address) continue;
      await pool.query(
        `UPDATE auctions SET venue_name = ?, venue_address = ?, venue_lat = ?, venue_lng = ? WHERE id = ?`,
        [v.venue_name || null, v.venue_address || null, v.venue_lat ?? null, v.venue_lng ?? null, id]
      );
      applied++;
    }
  }

  const [rows] = await pool.query(
    `SELECT id, status, DATE_FORMAT(start_time,'%d %b %H:%i') AS start_at, DATE_FORMAT(end_time,'%d %b %H:%i') AS end_at,
            venue_name FROM auctions WHERE id IN (?) ORDER BY end_time, id`, [ids]
  );
  const [[now]] = await pool.query(`SELECT DATE_FORMAT(NOW(), '%d %b %Y %H:%i:%s') AS now`);
  console.log(`DB time (IST): ${now.now}`);
  console.table(rows);
  console.log(`Prices updated on ${priced} auction(s); upcoming items re-timed.`);
  console.log(`Venues applied: ${applied}/${Object.keys(ENDS).length + 6} possible. ` +
    `Auctions without a venue will show a disabled Directions button.`);
  await pool.end();
}

main().catch((err) => { console.error(err); process.exit(1); });
