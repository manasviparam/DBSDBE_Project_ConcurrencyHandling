-- Online Auction & Bidding Platform - Schema
-- Engine MUST be InnoDB (row-level locking / transactions require it)

CREATE DATABASE IF NOT EXISTS auction_platform;
USE auction_platform;

DROP TABLE IF EXISTS visits;
DROP TABLE IF EXISTS watchlist;
DROP TABLE IF EXISTS auction_results;
DROP TABLE IF EXISTS bids;
DROP TABLE IF EXISTS auctions;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('user','admin') NOT NULL DEFAULT 'user',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE products (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(150) NOT NULL,
  description TEXT,
  image_url VARCHAR(500),
  category VARCHAR(50),
  is_certified BOOLEAN NOT NULL DEFAULT FALSE,
  created_by INT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE auctions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  product_id INT NOT NULL,
  starting_price DECIMAL(10,2) NOT NULL,
  current_highest_bid DECIMAL(10,2) NOT NULL DEFAULT 0,
  current_highest_bidder_id INT NULL,
  start_time DATETIME NOT NULL,
  end_time DATETIME NOT NULL,
  status ENUM('scheduled','active','closed') NOT NULL DEFAULT 'scheduled',
  approval_status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'approved',
  is_featured BOOLEAN NOT NULL DEFAULT FALSE,
  venue_name VARCHAR(150) NULL,
  venue_address VARCHAR(300) NULL,
  venue_lat DECIMAL(9,6) NULL,
  venue_lng DECIMAL(9,6) NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (product_id) REFERENCES products(id) ON DELETE RESTRICT,
  FOREIGN KEY (current_highest_bidder_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE bids (
  id INT AUTO_INCREMENT PRIMARY KEY,
  auction_id INT NOT NULL,
  user_id INT NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (auction_id) REFERENCES auctions(id) ON DELETE RESTRICT,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE RESTRICT,
  INDEX idx_auction_amount (auction_id, amount)
) ENGINE=InnoDB;

CREATE TABLE auction_results (
  auction_id INT PRIMARY KEY,
  winning_bid_id INT,
  winner_id INT,
  finalized_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (auction_id) REFERENCES auctions(id) ON DELETE RESTRICT,
  FOREIGN KEY (winning_bid_id) REFERENCES bids(id) ON DELETE SET NULL,
  FOREIGN KEY (winner_id) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE watchlist (
  user_id INT NOT NULL,
  auction_id INT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, auction_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (auction_id) REFERENCES auctions(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE visits (
  user_id INT NOT NULL,
  auction_id INT NOT NULL,
  visit_time DATETIME NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id, auction_id),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (auction_id) REFERENCES auctions(id) ON DELETE CASCADE
) ENGINE=InnoDB;
