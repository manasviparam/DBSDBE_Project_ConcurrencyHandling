function registerSocketHandlers(io) {
  io.on('connection', (socket) => {
    socket.on('join_auction', (auctionId) => {
      socket.join(`auction_${auctionId}`);
    });

    socket.on('leave_auction', (auctionId) => {
      socket.leave(`auction_${auctionId}`);
    });

    // Personal room for targeted notifications (e.g. "you've been outbid").
    socket.on('identify', (userId) => {
      if (userId) socket.join(`user_${userId}`);
    });

    socket.on('disconnect', () => {
      // no-op; rooms are cleaned up automatically
    });
  });
}

module.exports = registerSocketHandlers;
