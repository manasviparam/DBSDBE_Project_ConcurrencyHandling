USE auction_platform;
SET time_zone = '+05:30'; -- Asia/Kolkata

-- password for all seeded users is: password123
-- (bcrypt hash generated with bcrypt.hashSync('password123', 10))
INSERT INTO users (name, email, password_hash, role) VALUES
('Admin User', 'admin@auction.com', '$2b$10$wjbTxG4bGfU.tPHlxVNSd.BBZLWCvb4fxhxazuFdClW5Lqje6.yW2', 'admin'),
('Test User', 'testuser@auction.com', '$2b$10$wjbTxG4bGfU.tPHlxVNSd.BBZLWCvb4fxhxazuFdClW5Lqje6.yW2', 'user'),
('Shravya Chowdary', 'shravya@auction.com', '$2b$10$wjbTxG4bGfU.tPHlxVNSd.BBZLWCvb4fxhxazuFdClW5Lqje6.yW2', 'user'),
('Test Bidder 1', 'bidder1@auction.com', '$2b$10$wjbTxG4bGfU.tPHlxVNSd.BBZLWCvb4fxhxazuFdClW5Lqje6.yW2', 'user'),
('Test Bidder 2', 'bidder2@auction.com', '$2b$10$wjbTxG4bGfU.tPHlxVNSd.BBZLWCvb4fxhxazuFdClW5Lqje6.yW2', 'user');

-- 24 products, 4 per category, each with a real product photo (Wikimedia Commons, freely licensed).
-- Ownership is diversified per theme: shravya lists Art & Antiques, bidder2 lists Watches &
-- Jewelry, testuser lists Collectibles, bidder1 lists Home & Garden (furniture); admin keeps
-- Electronics and Fashion as house inventory.
INSERT INTO products (id, name, description, image_url, category, created_by) VALUES
-- Electronics
(1, 'Gaming Laptop', 'RTX-series gaming laptop, 16GB RAM, 1TB SSD.', 'https://thumb.wikimedia.org/wikipedia/commons/thumb/c/c9/MSI_Gaming_Laptop_on_wood_floor.jpg/960px-MSI_Gaming_Laptop_on_wood_floor.jpg', 'Electronics', 1),
(2, 'Wireless Noise-Cancelling Headphones', 'Over-ear ANC headphones with 30-hour battery life.', 'https://thumb.wikimedia.org/wikipedia/commons/thumb/1/18/Apple_AirPods_Max_3.jpg/960px-Apple_AirPods_Max_3.jpg', 'Electronics', 1),
(3, 'Custom Mechanical Keyboard', 'Hand-built 75% keyboard, hot-swappable switches.', 'https://thumb.wikimedia.org/wikipedia/commons/thumb/7/7f/Beautiful_Mechanical_Keyboard.jpg/960px-Beautiful_Mechanical_Keyboard.jpg', 'Electronics', 1),
(4, '4K Camera Drone', 'Foldable quadcopter with 4K stabilized camera and 30min flight time.', 'https://thumb.wikimedia.org/wikipedia/commons/thumb/6/6a/Quadcopter_camera_drone_in_flight.jpg/960px-Quadcopter_camera_drone_in_flight.jpg', 'Electronics', 1),
-- Art & Antiques (shravya)
(5, 'Oil Painting "Sunset Over Hills"', 'Original signed oil on canvas, framed, 24x36in.', 'https://thumb.wikimedia.org/wikipedia/commons/thumb/6/61/Evening_Sunset_-_Douai_-_Impressionist_Landscape_Oil_Painting_by_Henri_Duhem_1909.jpg/960px-Evening_Sunset_-_Douai_-_Impressionist_Landscape_Oil_Painting_by_Henri_Duhem_1909.jpg', 'Art & Antiques', 3),
(6, 'Victorian Writing Desk', 'Restored mahogany writing desk with brass hardware.', 'https://thumb.wikimedia.org/wikipedia/commons/thumb/9/93/Antique_writing_desk_%28Frederiksborg_Museum%29.jpg/960px-Antique_writing_desk_%28Frederiksborg_Museum%29.jpg', 'Art & Antiques', 3),
(7, 'Bronze Horse Sculpture', 'Museum-quality cast bronze galloping horse sculpture on a display base.', 'https://thumb.wikimedia.org/wikipedia/commons/thumb/c/c3/Eastern_Han_Bronze_Galloping_Horse_%2810094802964%29.jpg/960px-Eastern_Han_Bronze_Galloping_Horse_%2810094802964%29.jpg', 'Art & Antiques', 3),
(8, 'Antique Terrestrial Globe', 'Hand-painted terrestrial globe on a turned wooden stand, 19th century style.', 'https://thumb.wikimedia.org/wikipedia/commons/thumb/3/34/Vera_Rubin_with_antique_globes.jpg/960px-Vera_Rubin_with_antique_globes.jpg', 'Art & Antiques', 3),
-- Watches & Jewelry (bidder2)
(9, 'Automatic Dive Watch', 'Swiss-movement automatic watch, sapphire crystal, 200m water resistant.', 'https://thumb.wikimedia.org/wikipedia/commons/thumb/b/b6/Invicta_Mens_Automatic_Pro_Diver_Watch_8926_%28edited%2C_without_background%29.jpg/960px-Invicta_Mens_Automatic_Pro_Diver_Watch_8926_%28edited%2C_without_background%29.jpg', 'Watches & Jewelry', 5),
(10, 'Diamond Tennis Bracelet', '14k gold bracelet with 3 carats total diamond weight.', 'https://thumb.wikimedia.org/wikipedia/commons/thumb/d/d4/Closeup_tennis_bracelet.jpg/960px-Closeup_tennis_bracelet.jpg', 'Watches & Jewelry', 5),
(11, 'Cultured Pearl Necklace', 'Long strand of cultured baroque saltwater pearls with a gold clasp.', 'https://thumb.wikimedia.org/wikipedia/commons/thumb/8/82/Long_pearl_necklace_with_cultured_baroque_saltwater_pearls_1.jpg/960px-Long_pearl_necklace_with_cultured_baroque_saltwater_pearls_1.jpg', 'Watches & Jewelry', 5),
(12, 'Antique Gold Pocket Watch', 'Solid gold pocket watch with hand-engraved case, fully functional movement.', 'https://thumb.wikimedia.org/wikipedia/commons/thumb/2/2d/Warsaw_Gold_pocket_watch_of_Fryderyk_Chopin_01.jpg/960px-Warsaw_Gold_pocket_watch_of_Fryderyk_Chopin_01.jpg', 'Watches & Jewelry', 5),
-- Collectibles (testuser)
(13, 'Vintage Camera', 'A classic 35mm film camera in working condition.', 'https://thumb.wikimedia.org/wikipedia/commons/thumb/c/c6/Vintage_Kodak_Junior_Six-20_Series_II_Folding_Film_Camera_%2815869618824%29.jpg/960px-Vintage_Kodak_Junior_Six-20_Series_II_Folding_Film_Camera_%2815869618824%29.jpg', 'Collectibles', 2),
(14, 'Signed Baseball', 'Game-used baseball with authenticated signature.', 'https://thumb.wikimedia.org/wikipedia/commons/thumb/1/1e/Baseball_%28crop%29.jpg/960px-Baseball_%28crop%29.jpg', 'Collectibles', 2),
(15, 'Rare Comic Book Bundle', 'Bagged and boarded first-print comic issues in near-mint condition.', 'https://thumb.wikimedia.org/wikipedia/commons/thumb/3/37/The_Beguiling_-_Free_Comic_Book_Day_%28495357915%29.jpg/960px-The_Beguiling_-_Free_Comic_Book_Day_%28495357915%29.jpg', 'Collectibles', 2),
(16, 'Vintage Vinyl Record Collection', 'Curated crate of vintage vinyl LPs across rock, jazz, and soul.', 'https://thumb.wikimedia.org/wikipedia/commons/thumb/e/e2/Vinyl_record_collection_in_The_Stacks_of_KDVS.jpg/960px-Vinyl_record_collection_in_The_Stacks_of_KDVS.jpg', 'Collectibles', 2),
-- Fashion
(17, 'Leather Bomber Jacket', 'Genuine leather jacket, size L, minimal wear.', 'https://thumb.wikimedia.org/wikipedia/commons/thumb/c/cc/Women_Bomber_Jacket_Back.jpg/960px-Women_Bomber_Jacket_Back.jpg', 'Fashion', 1),
(18, 'Designer Leather Handbag', 'Structured leather handbag with gold-tone hardware.', 'https://thumb.wikimedia.org/wikipedia/commons/thumb/4/4f/Handbag%2C_designer_unknown%2C_after_1945%2C_leather%2C_artificial_fiber%2C_metal_-_Mus%C3%A9e_de_la_mode_-_Montreal%2C_Canada_-_DSC07282.jpg/960px-Handbag%2C_designer_unknown%2C_after_1945%2C_leather%2C_artificial_fiber%2C_metal_-_Mus%C3%A9e_de_la_mode_-_Montreal%2C_Canada_-_DSC07282.jpg', 'Fashion', 1),
(19, 'Hand-Printed Silk Scarf', 'Hand block-printed pure silk scarf, vibrant colorway.', 'https://thumb.wikimedia.org/wikipedia/commons/thumb/5/54/Colored_silk_scarf_from_India_01.jpg/960px-Colored_silk_scarf_from_India_01.jpg', 'Fashion', 1),
(20, 'Designer Sunglasses', 'Polarized designer sunglasses with case and cleaning cloth.', 'https://thumb.wikimedia.org/wikipedia/commons/thumb/9/9d/2008-07-27_Sunglasses.jpg/960px-2008-07-27_Sunglasses.jpg', 'Fashion', 1),
-- Home & Garden / furniture (bidder1)
(21, 'Antique Wall Clock', 'Hand-carved wooden wall clock, circa 1970s.', 'https://thumb.wikimedia.org/wikipedia/commons/thumb/6/68/Antique_wall_clock.jpg/960px-Antique_wall_clock.jpg', 'Home & Garden', 4),
(22, 'Persian Area Rug', 'Hand-knotted wool rug, 8x10ft, deep red and navy.', 'https://thumb.wikimedia.org/wikipedia/commons/thumb/1/11/Persian_Carpet.jpg/960px-Persian_Carpet.jpg', 'Home & Garden', 4),
(23, 'Ceramic Vase Set', 'Set of hand-thrown ceramic vases with a glazed finish.', 'https://thumb.wikimedia.org/wikipedia/commons/thumb/1/1f/A_Ceramic_Vase_in_Kanazawa.jpg/960px-A_Ceramic_Vase_in_Kanazawa.jpg', 'Home & Garden', 4),
(24, 'Outdoor Patio Furniture Set', 'Weather-resistant patio table and chair set for 4.', 'https://thumb.wikimedia.org/wikipedia/commons/thumb/4/46/Garden_furniture_at_Nuthurst_West_Sussex_England.jpg/960px-Garden_furniture_at_Nuthurst_West_Sussex_England.jpg', 'Home & Garden', 4);

-- Items submitted by users, still awaiting admin verification (populates the Approvals tab).
INSERT INTO products (id, name, description, image_url, category, is_certified, created_by) VALUES
(25, 'Antique Silver Tea Set', 'Hand-chased sterling silver four-piece tea service, early 20th century, monogrammed.', 'https://thumb.wikimedia.org/wikipedia/commons/thumb/c/c3/Eastern_Han_Bronze_Galloping_Horse_%2810094802964%29.jpg/960px-Eastern_Han_Bronze_Galloping_Horse_%2810094802964%29.jpg', 'Art & Antiques', TRUE, 3),
(26, 'Reclaimed Oak Farmhouse Table', 'Solid reclaimed oak dining table, seats eight, hand-finished.', 'https://thumb.wikimedia.org/wikipedia/commons/thumb/4/46/Garden_furniture_at_Nuthurst_West_Sussex_England.jpg/960px-Garden_furniture_at_Nuthurst_West_Sussex_England.jpg', 'Home & Garden', FALSE, 4),
(27, 'Vintage Chronograph Pocket Watch', 'Solid gold chronograph pocket watch, hand-engraved case, fully serviced movement.', 'https://thumb.wikimedia.org/wikipedia/commons/thumb/2/2d/Warsaw_Gold_pocket_watch_of_Fryderyk_Chopin_01.jpg/960px-Warsaw_Gold_pocket_watch_of_Fryderyk_Chopin_01.jpg', 'Watches & Jewelry', TRUE, 5),
(28, 'First-Edition Pulp Magazine Set', 'Bundle of first-edition pulp fiction magazines, bagged and boarded, near-mint.', 'https://thumb.wikimedia.org/wikipedia/commons/thumb/3/37/The_Beguiling_-_Free_Comic_Book_Day_%28495357915%29.jpg/960px-The_Beguiling_-_Free_Comic_Book_Day_%28495357915%29.jpg', 'Collectibles', FALSE, 2);

-- Proof-of-authenticity certification: art, antiques, watches & jewelry, and two
-- provenance-sensitive collectibles carry a certificate; everyday goods don't.
UPDATE products SET is_certified = TRUE WHERE id IN (5, 6, 7, 8, 9, 10, 11, 12, 13, 14);

-- 24 auctions: 18 expo items are live from the moment the seed runs, ending staggered up to
-- 16:00 IST on 3 Oct 2026 (later of the planned time and now+30..115 min),
-- 6 stay scheduled for later. Every category keeps at least one scheduled auction.
-- 4 are flagged featured.
INSERT INTO auctions (id, product_id, starting_price, current_highest_bid, start_time, end_time, status, is_featured) VALUES
(1, 1, 20000.00, 20000.00, NOW(), GREATEST('2026-10-03 14:45:00', DATE_ADD(NOW(), INTERVAL 65 MINUTE)), 'active', FALSE),
(2, 2, 150.00, 150.00, NOW(), GREATEST('2026-10-03 13:15:00', DATE_ADD(NOW(), INTERVAL 35 MINUTE)), 'active', TRUE),
(3, 3, 180.00, 180.00, GREATEST('2026-10-03 16:30:00', DATE_ADD(NOW(), INTERVAL 3 HOUR)), GREATEST('2026-10-04 16:30:00', DATE_ADD(NOW(), INTERVAL 27 HOUR)), 'scheduled', FALSE),
(4, 4, 8000.00, 8000.00, NOW(), GREATEST('2026-10-03 15:05:00', DATE_ADD(NOW(), INTERVAL 75 MINUTE)), 'active', FALSE),
(5, 5, 1200.00, 1200.00, NOW(), GREATEST('2026-10-03 16:00:00', DATE_ADD(NOW(), INTERVAL 105 MINUTE)), 'active', FALSE),
(6, 6, 900.00, 900.00, NOW(), GREATEST('2026-10-03 15:30:00', DATE_ADD(NOW(), INTERVAL 90 MINUTE)), 'active', FALSE),
(7, 7, 15000.00, 15000.00, NOW(), GREATEST('2026-10-03 14:00:00', DATE_ADD(NOW(), INTERVAL 50 MINUTE)), 'active', FALSE),
(8, 8, 600.00, 600.00, GREATEST('2026-10-03 17:00:00', DATE_ADD(NOW(), INTERVAL 4 HOUR)), GREATEST('2026-10-04 17:00:00', DATE_ADD(NOW(), INTERVAL 28 HOUR)), 'scheduled', FALSE),
(9, 9, 5000.00, 5000.00, NOW(), GREATEST('2026-10-03 14:15:00', DATE_ADD(NOW(), INTERVAL 55 MINUTE)), 'active', TRUE),
(10, 10, 8000.00, 8000.00, GREATEST('2026-10-03 17:30:00', DATE_ADD(NOW(), INTERVAL 5 HOUR)), GREATEST('2026-10-04 17:30:00', DATE_ADD(NOW(), INTERVAL 29 HOUR)), 'scheduled', FALSE),
(11, 11, 2500.00, 2500.00, NOW(), GREATEST('2026-10-03 13:45:00', DATE_ADD(NOW(), INTERVAL 45 MINUTE)), 'active', TRUE),
(12, 12, 4000.00, 4000.00, NOW(), GREATEST('2026-10-03 15:25:00', DATE_ADD(NOW(), INTERVAL 85 MINUTE)), 'active', FALSE),
(13, 13, 500.00, 500.00, NOW(), GREATEST('2026-10-03 14:30:00', DATE_ADD(NOW(), INTERVAL 60 MINUTE)), 'active', FALSE),
(14, 14, 250.00, 250.00, NOW(), GREATEST('2026-10-03 16:00:00', DATE_ADD(NOW(), INTERVAL 110 MINUTE)), 'active', FALSE),
(15, 15, 300.00, 300.00, GREATEST('2026-10-03 18:00:00', DATE_ADD(NOW(), INTERVAL 6 HOUR)), GREATEST('2026-10-04 18:00:00', DATE_ADD(NOW(), INTERVAL 30 HOUR)), 'scheduled', FALSE),
(16, 16, 150.00, 150.00, NOW(), GREATEST('2026-10-03 15:00:00', DATE_ADD(NOW(), INTERVAL 70 MINUTE)), 'active', FALSE),
(17, 17, 300.00, 300.00, NOW(), GREATEST('2026-10-03 15:40:00', DATE_ADD(NOW(), INTERVAL 95 MINUTE)), 'active', FALSE),
(18, 18, 1800.00, 1800.00, NOW(), GREATEST('2026-10-03 13:30:00', DATE_ADD(NOW(), INTERVAL 40 MINUTE)), 'active', TRUE),
(19, 19, 80.00, 80.00, GREATEST('2026-10-03 18:30:00', DATE_ADD(NOW(), INTERVAL 7 HOUR)), GREATEST('2026-10-04 18:30:00', DATE_ADD(NOW(), INTERVAL 31 HOUR)), 'scheduled', FALSE),
(20, 20, 200.00, 200.00, NOW(), GREATEST('2026-10-03 15:50:00', DATE_ADD(NOW(), INTERVAL 100 MINUTE)), 'active', FALSE),
(21, 21, 300.00, 300.00, DATE_ADD(NOW(), INTERVAL 2 MONTH), DATE_ADD(NOW(), INTERVAL 2 MONTH) + INTERVAL 2 DAY, 'scheduled', FALSE),
(22, 22, 2000.00, 2000.00, NOW(), GREATEST('2026-10-03 15:15:00', DATE_ADD(NOW(), INTERVAL 80 MINUTE)), 'active', FALSE),
(23, 23, 150.00, 150.00, NOW(), GREATEST('2026-10-03 13:00:00', DATE_ADD(NOW(), INTERVAL 30 MINUTE)), 'active', FALSE),
(24, 24, 1200.00, 1200.00, NOW(), GREATEST('2026-10-03 16:00:00', DATE_ADD(NOW(), INTERVAL 115 MINUTE)), 'active', FALSE);

-- Items listed by users but not yet authorised by admin (the Approvals tab demo).
INSERT INTO auctions (id, product_id, starting_price, current_highest_bid, start_time, end_time, status, approval_status, is_featured) VALUES
(25, 25, 1400.00, 1400.00, DATE_ADD(NOW(), INTERVAL 6 HOUR), DATE_ADD(NOW(), INTERVAL 3 DAY), 'scheduled', 'pending', FALSE),
(26, 26, 2200.00, 2200.00, DATE_ADD(NOW(), INTERVAL 8 HOUR), DATE_ADD(NOW(), INTERVAL 4 DAY), 'scheduled', 'pending', FALSE),
(27, 27, 3200.00, 3200.00, DATE_ADD(NOW(), INTERVAL 10 HOUR), DATE_ADD(NOW(), INTERVAL 2 DAY), 'scheduled', 'pending', FALSE),
(28, 28, 220.00, 220.00, DATE_ADD(NOW(), INTERVAL 12 HOUR), DATE_ADD(NOW(), INTERVAL 5 DAY), 'scheduled', 'pending', FALSE);

-- Bid history (users: 2=Test User, 3=Shravya, 4=Bidder1, 5=Bidder2)
INSERT INTO bids (auction_id, user_id, amount) VALUES
(1, 4, 20500.00), (1, 2, 21000.00), (1, 5, 21500.00),
(2, 3, 180.00), (2, 5, 250.00), (2, 2, 320.00),
(4, 2, 8700.00), (4, 4, 9500.00),
(5, 2, 1400.00), (5, 4, 1800.00),
(6, 3, 1100.00), (6, 5, 1350.00),
(7, 4, 16000.00), (7, 3, 17200.00), (7, 2, 18000.00),
(9, 4, 5200.00), (9, 5, 5800.00), (9, 3, 6200.00),
(11, 2, 2800.00), (11, 5, 3200.00),
(12, 3, 4400.00), (12, 4, 4800.00),
(13, 4, 600.00), (13, 5, 650.00), (13, 2, 700.00), (13, 3, 750.00),
(14, 4, 300.00), (14, 3, 400.00),
(16, 2, 200.00), (16, 5, 280.00),
(18, 3, 2000.00), (18, 2, 2400.00),
(20, 4, 260.00), (20, 3, 320.00),
(22, 2, 2200.00), (22, 4, 2600.00),
(23, 5, 180.00), (23, 3, 220.00);

-- Reflect the highest bid on each auction row (mirrors what placeBidTransaction would have set)
UPDATE auctions SET current_highest_bid = 21500.00, current_highest_bidder_id = 5 WHERE id = 1;
UPDATE auctions SET current_highest_bid = 320.00, current_highest_bidder_id = 2 WHERE id = 2;
UPDATE auctions SET current_highest_bid = 9500.00, current_highest_bidder_id = 4 WHERE id = 4;
UPDATE auctions SET current_highest_bid = 1800.00, current_highest_bidder_id = 4 WHERE id = 5;
UPDATE auctions SET current_highest_bid = 1350.00, current_highest_bidder_id = 5 WHERE id = 6;
UPDATE auctions SET current_highest_bid = 18000.00, current_highest_bidder_id = 2 WHERE id = 7;
UPDATE auctions SET current_highest_bid = 6200.00, current_highest_bidder_id = 3 WHERE id = 9;
UPDATE auctions SET current_highest_bid = 3200.00, current_highest_bidder_id = 5 WHERE id = 11;
UPDATE auctions SET current_highest_bid = 4800.00, current_highest_bidder_id = 4 WHERE id = 12;
UPDATE auctions SET current_highest_bid = 750.00, current_highest_bidder_id = 3 WHERE id = 13;
UPDATE auctions SET current_highest_bid = 400.00, current_highest_bidder_id = 3 WHERE id = 14;
UPDATE auctions SET current_highest_bid = 280.00, current_highest_bidder_id = 5 WHERE id = 16;
UPDATE auctions SET current_highest_bid = 2400.00, current_highest_bidder_id = 2 WHERE id = 18;
UPDATE auctions SET current_highest_bid = 320.00, current_highest_bidder_id = 3 WHERE id = 20;
UPDATE auctions SET current_highest_bid = 2600.00, current_highest_bidder_id = 4 WHERE id = 22;
UPDATE auctions SET current_highest_bid = 220.00, current_highest_bidder_id = 3 WHERE id = 23;

-- Results for the two auctions that stay 'closed' (completed) after seeding


-- Realistic starting prices (INR). Existing bids are scaled by the same factor so the history
-- stays consistent (every bid remains above the new starting price).
CREATE TEMPORARY TABLE new_prices (auction_id INT PRIMARY KEY, price DECIMAL(10,2));
INSERT INTO new_prices (auction_id, price) VALUES
(1, 85000.00),
(2, 9000.00),
(3, 6500.00),
(4, 35000.00),
(5, 25000.00),
(6, 45000.00),
(7, 60000.00),
(8, 18000.00),
(9, 30000.00),
(10, 350000.00),
(11, 20000.00),
(12, 120000.00),
(13, 8000.00),
(14, 12000.00),
(15, 15000.00),
(16, 10000.00),
(17, 7000.00),
(18, 90000.00),
(19, 3500.00),
(20, 9000.00),
(21, 15000.00),
(22, 80000.00),
(23, 4000.00),
(24, 40000.00),
(25, 55000.00),
(26, 65000.00),
(27, 70000.00),
(28, 12000.00);
UPDATE bids b JOIN auctions a ON a.id = b.auction_id JOIN new_prices n ON n.auction_id = a.id
SET b.amount = ROUND(b.amount * n.price / a.starting_price, IF(n.price >= 10000, -2, -1))
WHERE a.starting_price <> n.price;
UPDATE auctions a JOIN new_prices n ON n.auction_id = a.id
SET a.current_highest_bid = COALESCE((SELECT MAX(b.amount) FROM bids b WHERE b.auction_id = a.id), n.price),
    a.starting_price = n.price
WHERE a.starting_price <> n.price;
DROP TEMPORARY TABLE new_prices;

-- Sample expo venues (random Hyderabad landmarks) - edit freely.
UPDATE auctions SET venue_name = 'Nexus Hyderabad Mall (Forum Sujana), KPHB', venue_address = 'KPHB Colony, Kukatpally, Hyderabad, Telangana 500072', venue_lat = 17.4934, venue_lng = 78.3918 WHERE id = 1;
UPDATE auctions SET venue_name = 'Inorbit Mall, Madhapur', venue_address = 'Survey No 64, Madhapur, Hyderabad, Telangana 500081', venue_lat = 17.4344, venue_lng = 78.3871 WHERE id = 2;
UPDATE auctions SET venue_name = 'GVK One Mall, Banjara Hills', venue_address = 'Road No. 1, Banjara Hills, Hyderabad, Telangana 500034', venue_lat = 17.4172, venue_lng = 78.4486 WHERE id = 3;
UPDATE auctions SET venue_name = 'HITEX Exhibition Centre', venue_address = 'Izzat Nagar, Madhapur, Hyderabad, Telangana 500084', venue_lat = 17.4745, venue_lng = 78.3781 WHERE id = 4;
UPDATE auctions SET venue_name = 'Sarath City Capital Mall, Kondapur', venue_address = 'Kondapur, Hyderabad, Telangana 500084', venue_lat = 17.4617, venue_lng = 78.3615 WHERE id = 5;
UPDATE auctions SET venue_name = 'Shilparamam Arts & Crafts Village', venue_address = 'Madhapur, Hyderabad, Telangana 500081', venue_lat = 17.4524, venue_lng = 78.3786 WHERE id = 6;
UPDATE auctions SET venue_name = 'HICC Novotel Convention Centre', venue_address = 'Cyberabad, Madhapur, Hyderabad, Telangana 500081', venue_lat = 17.4244, venue_lng = 78.3753 WHERE id = 7;
UPDATE auctions SET venue_name = 'Nexus Hyderabad Mall (Forum Sujana), KPHB', venue_address = 'KPHB Colony, Kukatpally, Hyderabad, Telangana 500072', venue_lat = 17.4934, venue_lng = 78.3918 WHERE id = 8;
UPDATE auctions SET venue_name = 'Inorbit Mall, Madhapur', venue_address = 'Survey No 64, Madhapur, Hyderabad, Telangana 500081', venue_lat = 17.4344, venue_lng = 78.3871 WHERE id = 9;
UPDATE auctions SET venue_name = 'GVK One Mall, Banjara Hills', venue_address = 'Road No. 1, Banjara Hills, Hyderabad, Telangana 500034', venue_lat = 17.4172, venue_lng = 78.4486 WHERE id = 10;
UPDATE auctions SET venue_name = 'HITEX Exhibition Centre', venue_address = 'Izzat Nagar, Madhapur, Hyderabad, Telangana 500084', venue_lat = 17.4745, venue_lng = 78.3781 WHERE id = 11;
UPDATE auctions SET venue_name = 'Sarath City Capital Mall, Kondapur', venue_address = 'Kondapur, Hyderabad, Telangana 500084', venue_lat = 17.4617, venue_lng = 78.3615 WHERE id = 12;
UPDATE auctions SET venue_name = 'Shilparamam Arts & Crafts Village', venue_address = 'Madhapur, Hyderabad, Telangana 500081', venue_lat = 17.4524, venue_lng = 78.3786 WHERE id = 13;
UPDATE auctions SET venue_name = 'HICC Novotel Convention Centre', venue_address = 'Cyberabad, Madhapur, Hyderabad, Telangana 500081', venue_lat = 17.4244, venue_lng = 78.3753 WHERE id = 14;
UPDATE auctions SET venue_name = 'Nexus Hyderabad Mall (Forum Sujana), KPHB', venue_address = 'KPHB Colony, Kukatpally, Hyderabad, Telangana 500072', venue_lat = 17.4934, venue_lng = 78.3918 WHERE id = 15;
UPDATE auctions SET venue_name = 'Inorbit Mall, Madhapur', venue_address = 'Survey No 64, Madhapur, Hyderabad, Telangana 500081', venue_lat = 17.4344, venue_lng = 78.3871 WHERE id = 16;
UPDATE auctions SET venue_name = 'GVK One Mall, Banjara Hills', venue_address = 'Road No. 1, Banjara Hills, Hyderabad, Telangana 500034', venue_lat = 17.4172, venue_lng = 78.4486 WHERE id = 17;
UPDATE auctions SET venue_name = 'HITEX Exhibition Centre', venue_address = 'Izzat Nagar, Madhapur, Hyderabad, Telangana 500084', venue_lat = 17.4745, venue_lng = 78.3781 WHERE id = 18;
UPDATE auctions SET venue_name = 'Sarath City Capital Mall, Kondapur', venue_address = 'Kondapur, Hyderabad, Telangana 500084', venue_lat = 17.4617, venue_lng = 78.3615 WHERE id = 19;
UPDATE auctions SET venue_name = 'Shilparamam Arts & Crafts Village', venue_address = 'Madhapur, Hyderabad, Telangana 500081', venue_lat = 17.4524, venue_lng = 78.3786 WHERE id = 20;
UPDATE auctions SET venue_name = 'HICC Novotel Convention Centre', venue_address = 'Cyberabad, Madhapur, Hyderabad, Telangana 500081', venue_lat = 17.4244, venue_lng = 78.3753 WHERE id = 21;
UPDATE auctions SET venue_name = 'Nexus Hyderabad Mall (Forum Sujana), KPHB', venue_address = 'KPHB Colony, Kukatpally, Hyderabad, Telangana 500072', venue_lat = 17.4934, venue_lng = 78.3918 WHERE id = 22;
UPDATE auctions SET venue_name = 'Inorbit Mall, Madhapur', venue_address = 'Survey No 64, Madhapur, Hyderabad, Telangana 500081', venue_lat = 17.4344, venue_lng = 78.3871 WHERE id = 23;
UPDATE auctions SET venue_name = 'GVK One Mall, Banjara Hills', venue_address = 'Road No. 1, Banjara Hills, Hyderabad, Telangana 500034', venue_lat = 17.4172, venue_lng = 78.4486 WHERE id = 24;

-- A few starter watchlist entries so the Watchlist page isn't empty on first login
INSERT INTO watchlist (user_id, auction_id) VALUES
(2, 2), (2, 9), (2, 18),
(3, 13), (3, 7);
