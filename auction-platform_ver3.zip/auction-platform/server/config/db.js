require('dotenv').config();
const mysql = require('mysql2/promise');

// A connection pool is required (not single connection) so that concurrent
// bid requests can each get their own connection and hold their own
// transaction/lock independently.
const pool = mysql.createPool({
  host: process.env.DB_HOST,
  port: process.env.DB_PORT || 3306,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 20,
  queueLimit: 0,
  timezone: '+05:30', // Asia/Kolkata - keeps DATETIME <-> JS Date conversion in IST
});

// Make NOW() inside every pooled connection use IST too, so the cron job's
// start_time/end_time comparisons match the expo timings (12:00-16:00 IST).
pool.pool.on('connection', (conn) => {
  conn.query("SET time_zone = '+05:30'", (err) => { if (err) console.error('Failed to set session time zone:', err.message); });
});

module.exports = pool;
