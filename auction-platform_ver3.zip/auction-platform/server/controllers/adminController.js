const pool = require('../config/db');

async function listUsers(req, res) {
  try {
    const [rows] = await pool.query('SELECT id, name, email, role, created_at FROM users ORDER BY id');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch users' });
  }
}

async function listAllBids(req, res) {
  try {
    const [rows] = await pool.query(`
      SELECT b.*, u.name AS bidder_name, a.id AS auction_id, p.name AS product_name
      FROM bids b
      JOIN users u ON u.id = b.user_id
      JOIN auctions a ON a.id = b.auction_id
      JOIN products p ON p.id = a.product_id
      ORDER BY b.created_at DESC
      LIMIT 200
    `);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch bids' });
  }
}

async function updateUserRole(req, res) {
  try {
    const { id } = req.params;
    const { role } = req.body;
    if (!['user', 'admin'].includes(role)) {
      return res.status(400).json({ error: "role must be 'user' or 'admin'" });
    }
    const [result] = await pool.query('UPDATE users SET role = ? WHERE id = ?', [role, id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'User not found' });
    res.json({ id: Number(id), role });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to update user role' });
  }
}

async function deleteUser(req, res) {
  try {
    const { id } = req.params;
    if (Number(id) === req.user.id) {
      return res.status(400).json({ error: "You can't delete your own account" });
    }
    const [result] = await pool.query('DELETE FROM users WHERE id = ?', [id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'User not found' });
    res.status(204).end();
  } catch (err) {
    if (err.errno === 1451) {
      return res.status(409).json({ error: 'This user has placed bids and cannot be deleted' });
    }
    console.error(err);
    res.status(500).json({ error: 'Failed to delete user' });
  }
}

function localDateKey(d) {
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}

async function getStats(req, res) {
  try {
    const [[userCount]] = await pool.query('SELECT COUNT(*) AS count FROM users');
    const [statusCounts] = await pool.query(
      `SELECT status, COUNT(*) AS count FROM auctions GROUP BY status`
    );
    const [[bidsToday]] = await pool.query(
      `SELECT COUNT(*) AS count FROM bids WHERE DATE(created_at) = CURDATE()`
    );
    const [[activeValue]] = await pool.query(
      `SELECT COALESCE(SUM(current_highest_bid), 0) AS total FROM auctions WHERE status = 'active'`
    );
    const [[pendingApprovals]] = await pool.query(
      `SELECT COUNT(*) AS count FROM auctions WHERE approval_status = 'pending'`
    );
    const [bidsPerDayRows] = await pool.query(
      `SELECT DATE_FORMAT(created_at, '%Y-%m-%d') AS day, COUNT(*) AS count
       FROM bids
       WHERE created_at >= DATE_SUB(CURDATE(), INTERVAL 6 DAY)
       GROUP BY DATE_FORMAT(created_at, '%Y-%m-%d')`
    );

    const statusMap = { active: 0, scheduled: 0, closed: 0 };
    statusCounts.forEach((row) => { statusMap[row.status] = row.count; });

    // Zero-fill every one of the last 7 days so the chart always shows a full week,
    // not just the days that happen to have bids.
    const countByDay = new Map(bidsPerDayRows.map((r) => [r.day, r.count]));
    const bidsPerDay = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const key = localDateKey(d);
      bidsPerDay.push({ day: key, count: countByDay.get(key) || 0 });
    }

    res.json({
      userCount: userCount.count,
      auctionsByStatus: statusMap,
      bidsToday: bidsToday.count,
      activeAuctionsValue: Number(activeValue.total),
      pendingApprovals: pendingApprovals.count,
      bidsPerDay,
    });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch stats' });
  }
}

async function listPendingAuctions(req, res) {
  try {
    const [rows] = await pool.query(`
      SELECT a.id, a.starting_price, a.start_time, a.end_time, a.status, a.approval_status,
             p.name AS product_name, p.description AS product_description, p.image_url,
             p.category, p.is_certified,
             u.id AS submitted_by_id, u.name AS submitted_by, u.email AS submitted_by_email
      FROM auctions a
      JOIN products p ON p.id = a.product_id
      LEFT JOIN users u ON u.id = p.created_by
      WHERE a.approval_status = 'pending'
      ORDER BY a.created_at DESC
    `);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch pending auctions' });
  }
}

async function setAuctionApproval(req, res) {
  try {
    const { id } = req.params;
    const { approval_status } = req.body;
    if (!['approved', 'rejected'].includes(approval_status)) {
      return res.status(400).json({ error: "approval_status must be 'approved' or 'rejected'" });
    }
    const [result] = await pool.query('UPDATE auctions SET approval_status = ? WHERE id = ?', [approval_status, id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Auction not found' });
    res.json({ id: Number(id), approval_status });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to update approval status' });
  }
}

module.exports = { listUsers, listAllBids, updateUserRole, deleteUser, getStats, listPendingAuctions, setAuctionApproval };
