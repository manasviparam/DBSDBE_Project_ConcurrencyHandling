const pool = require('../config/db');

async function myBids(req, res) {
  try {
    const [rows] = await pool.query(
      `SELECT b.id AS bid_id, b.amount, b.created_at, a.id AS auction_id, a.status, a.current_highest_bid,
              p.name AS product_name, p.image_url, p.category
       FROM bids b
       JOIN auctions a ON a.id = b.auction_id
       JOIN products p ON p.id = a.product_id
       WHERE b.user_id = ?
       ORDER BY b.created_at DESC`,
      [req.user.id]
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch your bids' });
  }
}

async function myWonAuctions(req, res) {
  try {
    const [rows] = await pool.query(
      `SELECT r.auction_id, r.finalized_at, b.amount AS winning_amount,
              a.status, p.name AS product_name, p.image_url, p.category
       FROM auction_results r
       JOIN bids b ON b.id = r.winning_bid_id
       JOIN auctions a ON a.id = r.auction_id
       JOIN products p ON p.id = a.product_id
       WHERE r.winner_id = ?
       ORDER BY r.finalized_at DESC`,
      [req.user.id]
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch won auctions' });
  }
}

module.exports = { myBids, myWonAuctions };
