const pool = require('../config/db');

async function listWatchlist(req, res) {
  try {
    const [rows] = await pool.query(
      `SELECT a.*, p.name AS product_name, p.description AS product_description, p.image_url, p.category, p.is_certified,
              COUNT(b.id) AS bid_count, COUNT(DISTINCT b.user_id) AS bidder_count
       FROM watchlist w
       JOIN auctions a ON a.id = w.auction_id
       JOIN products p ON p.id = a.product_id
       LEFT JOIN bids b ON b.auction_id = a.id
       WHERE w.user_id = ?
       GROUP BY a.id, w.created_at
       ORDER BY w.created_at DESC`,
      [req.user.id]
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch watchlist' });
  }
}

async function addToWatchlist(req, res) {
  try {
    const { auctionId } = req.params;
    await pool.query(
      'INSERT IGNORE INTO watchlist (user_id, auction_id) VALUES (?, ?)',
      [req.user.id, auctionId]
    );
    res.status(201).json({ watching: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to add to watchlist' });
  }
}

async function removeFromWatchlist(req, res) {
  try {
    const { auctionId } = req.params;
    await pool.query('DELETE FROM watchlist WHERE user_id = ? AND auction_id = ?', [req.user.id, auctionId]);
    res.json({ watching: false });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to remove from watchlist' });
  }
}

module.exports = { listWatchlist, addToWatchlist, removeFromWatchlist };
