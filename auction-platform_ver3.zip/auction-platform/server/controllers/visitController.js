const pool = require('../config/db');

async function listMyVisits(req, res) {
  try {
    const [rows] = await pool.query(
      `SELECT v.auction_id, v.visit_time, a.status, a.start_time, a.end_time,
              p.name AS product_name, p.image_url, p.category
       FROM visits v
       JOIN auctions a ON a.id = v.auction_id
       JOIN products p ON p.id = a.product_id
       WHERE v.user_id = ?
       ORDER BY v.visit_time ASC`,
      [req.user.id]
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch your scheduled visits' });
  }
}

async function scheduleVisit(req, res) {
  try {
    const { auctionId } = req.params;
    const { visit_time } = req.body;
    if (!visit_time) return res.status(400).json({ error: 'visit_time is required' });

    await pool.query(
      `INSERT INTO visits (user_id, auction_id, visit_time) VALUES (?, ?, ?)
       ON DUPLICATE KEY UPDATE visit_time = VALUES(visit_time)`,
      [req.user.id, auctionId, visit_time]
    );
    res.status(201).json({ scheduled: true, visit_time });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to schedule visit' });
  }
}

async function cancelVisit(req, res) {
  try {
    const { auctionId } = req.params;
    await pool.query('DELETE FROM visits WHERE user_id = ? AND auction_id = ?', [req.user.id, auctionId]);
    res.json({ scheduled: false });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to cancel visit' });
  }
}

module.exports = { listMyVisits, scheduleVisit, cancelVisit };
