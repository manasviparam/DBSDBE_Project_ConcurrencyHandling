const pool = require('../config/db');
const sleep = require('../utils/sleep');

/**
 * Core concurrency-safe bid placement.
 *
 * Wraps the read-check-write cycle in a single MySQL transaction and takes
 * a row-level lock (SELECT ... FOR UPDATE) on the target auction row so that
 * only one transaction can read/validate/update the current highest bid at
 * a time. InnoDB's default REPEATABLE READ isolation level combined with
 * this explicit lock prevents the classic lost-update race condition where
 * two users read the same "current highest bid" before either has written
 * their update.
 */
async function placeBidTransaction(auctionId, userId, amount) {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();

    // Row lock: any other transaction trying to SELECT ... FOR UPDATE the
    // same auction row will block here until this transaction commits or
    // rolls back.
    const [rows] = await connection.query(
      'SELECT current_highest_bid, current_highest_bidder_id, status, end_time FROM auctions WHERE id = ? FOR UPDATE',
      [auctionId]
    );

    if (rows.length === 0) {
      await connection.rollback();
      return { success: false, status: 404, error: 'Auction not found' };
    }

    const auction = rows[0];

    if (auction.status !== 'active') {
      await connection.rollback();
      return { success: false, status: 400, error: 'Auction is not active' };
    }

    if (new Date() > new Date(auction.end_time)) {
      await connection.rollback();
      return { success: false, status: 400, error: 'Auction has already ended' };
    }

    if (Number(amount) <= Number(auction.current_highest_bid)) {
      await connection.rollback();
      return {
        success: false,
        status: 409,
        error: `Bid must be higher than current highest bid (${auction.current_highest_bid})`,
      };
    }

    await connection.query(
      'UPDATE auctions SET current_highest_bid = ?, current_highest_bidder_id = ? WHERE id = ?',
      [amount, userId, auctionId]
    );

    const [insertResult] = await connection.query(
      'INSERT INTO bids (auction_id, user_id, amount) VALUES (?, ?, ?)',
      [auctionId, userId, amount]
    );

    await connection.commit();

    return {
      success: true,
      bidId: insertResult.insertId,
      auctionId: Number(auctionId),
      amount: Number(amount),
      previousBidderId: auction.current_highest_bidder_id || null,
    };
  } catch (err) {
    await connection.rollback();
    throw err;
  } finally {
    connection.release();
  }
}

/**
 * Retries on deadlock with jittered exponential backoff. Deadlocks are
 * expected under high concurrent load when multiple auctions are being bid
 * on across interleaved transactions; retrying is standard practice rather
 * than surfacing the deadlock to the end user.
 */
async function placeBidWithRetry(auctionId, userId, amount, retries = 3, attempt = 1) {
  try {
    return await placeBidTransaction(auctionId, userId, amount);
  } catch (err) {
    const isDeadlock = err.code === 'ER_LOCK_DEADLOCK' || err.errno === 1213;
    if (isDeadlock && retries > 0) {
      const backoff = 50 * attempt + Math.random() * 100;
      await sleep(backoff);
      return placeBidWithRetry(auctionId, userId, amount, retries - 1, attempt + 1);
    }
    throw err;
  }
}

async function placeBid(req, res) {
  try {
    const { id: auctionId } = req.params;
    const { amount } = req.body;
    const userId = req.user.id;

    if (!amount || Number(amount) <= 0) {
      return res.status(400).json({ error: 'A valid bid amount is required' });
    }

    const result = await placeBidWithRetry(auctionId, userId, amount);

    if (!result.success) {
      return res.status(result.status).json({ error: result.error });
    }

    // Broadcast the new highest bid to everyone connected — the auction list
    // and detail page both filter by auctionId, so a plain broadcast keeps
    // every card's price live, not just the one auction a room-scoped emit
    // would reach.
    const io = req.app.get('io');
    if (io) {
      io.emit('bid_update', {
        auctionId: Number(auctionId),
        currentHighestBid: result.amount,
        bidderId: userId,
        bidderName: req.user.name,
        time: new Date().toISOString(),
      });

      // Targeted real-time alert to whoever held the top bid before this one.
      if (result.previousBidderId && result.previousBidderId !== userId) {
        const [[product]] = await pool.query(
          `SELECT p.name AS product_name FROM auctions a
             JOIN products p ON p.id = a.product_id WHERE a.id = ?`,
          [auctionId]
        );
        io.to(`user_${result.previousBidderId}`).emit('outbid', {
          auctionId: Number(auctionId),
          productName: product?.product_name || 'an item',
          newAmount: result.amount,
          outbidBy: req.user.name,
        });
      }
    }

    res.status(201).json(result);
  } catch (err) {
    console.error('Bid placement failed:', err);
    res.status(500).json({ error: 'Failed to place bid due to a server error' });
  }
}

async function getBidHistory(req, res) {
  try {
    const { id: auctionId } = req.params;
    const [rows] = await pool.query(
      `SELECT b.id, b.amount, b.created_at, u.name AS bidder_name
       FROM bids b
       JOIN users u ON u.id = b.user_id
       WHERE b.auction_id = ?
       ORDER BY b.created_at DESC, b.id DESC`,
      [auctionId]
    );
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch bid history' });
  }
}

module.exports = { placeBid, getBidHistory, placeBidWithRetry };
