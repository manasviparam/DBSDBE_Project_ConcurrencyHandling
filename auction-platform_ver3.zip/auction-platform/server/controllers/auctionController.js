const pool = require('../config/db');

async function listAuctions(req, res) {
  try {
    const [rows] = await pool.query(`
      SELECT a.*, p.name AS product_name, p.description AS product_description, p.image_url, p.category, p.is_certified,
             COUNT(b.id) AS bid_count, COUNT(DISTINCT b.user_id) AS bidder_count
      FROM auctions a
      JOIN products p ON p.id = a.product_id
      LEFT JOIN bids b ON b.auction_id = a.id
      GROUP BY a.id
      ORDER BY a.start_time DESC
    `);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch auctions' });
  }
}

async function getAuction(req, res) {
  try {
    const { id } = req.params;
    const [rows] = await pool.query(`
      SELECT a.*, p.name AS product_name, p.description AS product_description, p.image_url, p.category, p.is_certified,
             COUNT(b.id) AS bid_count, COUNT(DISTINCT b.user_id) AS bidder_count
      FROM auctions a
      JOIN products p ON p.id = a.product_id
      LEFT JOIN bids b ON b.auction_id = a.id
      WHERE a.id = ?
      GROUP BY a.id
    `, [id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Auction not found' });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch auction' });
  }
}

async function createAuction(req, res) {
  try {
    const { product_id, starting_price, start_time, end_time } = req.body;
    if (!product_id || !starting_price || !start_time || !end_time) {
      return res.status(400).json({ error: 'product_id, starting_price, start_time, end_time are required' });
    }

    const status = new Date(start_time) <= new Date() ? 'active' : 'scheduled';

    const [result] = await pool.query(
      `INSERT INTO auctions
        (product_id, starting_price, current_highest_bid, start_time, end_time, status)
       VALUES (?, ?, ?, ?, ?, ?)`,
      [product_id, starting_price, starting_price, start_time, end_time, status]
    );
    res.status(201).json({ id: result.insertId });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create auction' });
  }
}

async function updateAuction(req, res) {
  try {
    const { id } = req.params;
    const { starting_price, start_time, end_time, is_featured } = req.body;
    if (!starting_price || !start_time || !end_time) {
      return res.status(400).json({ error: 'starting_price, start_time, end_time are required' });
    }

    const [existingRows] = await pool.query('SELECT status FROM auctions WHERE id = ?', [id]);
    if (existingRows.length === 0) return res.status(404).json({ error: 'Auction not found' });

    const status = new Date(end_time) <= new Date() ? 'closed' : (new Date(start_time) <= new Date() ? 'active' : 'scheduled');

    await pool.query(
      `UPDATE auctions SET starting_price = ?, start_time = ?, end_time = ?, is_featured = ?, status = ?
       WHERE id = ?`,
      [starting_price, start_time, end_time, !!is_featured, status, id]
    );
    res.json({ id: Number(id), starting_price, start_time, end_time, is_featured: !!is_featured, status });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to update auction' });
  }
}

async function closeAuctionNow(req, res) {
  try {
    const { id } = req.params;
    const { closeAuctionById } = require('../jobs/closeAuctions');
    const io = req.app.get('io');
    const closed = await closeAuctionById(id, io);
    if (!closed) return res.status(400).json({ error: 'Auction is not active or does not exist' });
    res.json({ closed: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to close auction' });
  }
}

async function deleteAuction(req, res) {
  try {
    const { id } = req.params;
    const [result] = await pool.query('DELETE FROM auctions WHERE id = ?', [id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Auction not found' });
    res.status(204).end();
  } catch (err) {
    if (err.errno === 1451) {
      return res.status(409).json({ error: 'This auction has bids and cannot be deleted' });
    }
    console.error(err);
    res.status(500).json({ error: 'Failed to delete auction' });
  }
}

async function getResult(req, res) {
  try {
    const { id } = req.params;
    const [rows] = await pool.query(`
      SELECT r.*, u.name AS winner_name, b.amount AS winning_amount
      FROM auction_results r
      LEFT JOIN users u ON u.id = r.winner_id
      LEFT JOIN bids b ON b.id = r.winning_bid_id
      WHERE r.auction_id = ?
    `, [id]);
    if (rows.length === 0) return res.status(404).json({ error: 'Result not available yet' });
    res.json(rows[0]);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch result' });
  }
}

module.exports = { listAuctions, getAuction, createAuction, updateAuction, closeAuctionNow, deleteAuction, getResult };
