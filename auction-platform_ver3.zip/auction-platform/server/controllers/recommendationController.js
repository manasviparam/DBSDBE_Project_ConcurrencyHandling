const pool = require('../config/db');

const baseSelect = `
  SELECT a.*, p.name AS product_name, p.description AS product_description, p.image_url, p.category, p.is_certified,
         COUNT(b.id) AS bid_count, COUNT(DISTINCT b.user_id) AS bidder_count
  FROM auctions a
  JOIN products p ON p.id = a.product_id
  LEFT JOIN bids b ON b.auction_id = a.id
`;

async function getRecommendations(req, res) {
  try {
    const { category, exclude } = req.query;
    const limit = 8;

    // Detail-page mode: "more like this" within one category.
    if (category) {
      const params = [category, 'active'];
      let sql = `${baseSelect} WHERE p.category = ? AND a.status = ?`;
      if (exclude) {
        sql += ' AND a.id != ?';
        params.push(exclude);
      }
      sql += ' GROUP BY a.id ORDER BY a.end_time ASC LIMIT ?';
      params.push(limit);
      const [rows] = await pool.query(sql, params);
      return res.json(rows);
    }

    // Personalized mode: categories the user has bid on or watchlisted.
    if (req.user) {
      const [categoryRows] = await pool.query(
        `SELECT DISTINCT p.category FROM bids b
           JOIN auctions a ON a.id = b.auction_id
           JOIN products p ON p.id = a.product_id
          WHERE b.user_id = ? AND p.category IS NOT NULL
         UNION
         SELECT DISTINCT p.category FROM watchlist w
           JOIN auctions a ON a.id = w.auction_id
           JOIN products p ON p.id = a.product_id
          WHERE w.user_id = ? AND p.category IS NOT NULL`,
        [req.user.id, req.user.id]
      );
      const categories = categoryRows.map((r) => r.category);

      if (categories.length > 0) {
        const [rows] = await pool.query(
          `${baseSelect}
           WHERE a.status = 'active' AND p.category IN (?)
             AND a.id NOT IN (SELECT auction_id FROM bids WHERE user_id = ?)
           GROUP BY a.id
           ORDER BY a.end_time ASC LIMIT ?`,
          [categories, req.user.id, limit]
        );
        if (rows.length > 0) return res.json(rows);
      }
    }

    // Fallback: trending active auctions (most bids).
    const [trending] = await pool.query(
      `${baseSelect}
       WHERE a.status = 'active'
       GROUP BY a.id
       ORDER BY bid_count DESC, a.end_time ASC
       LIMIT ?`,
      [limit]
    );
    res.json(trending);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch recommendations' });
  }
}

module.exports = { getRecommendations };
