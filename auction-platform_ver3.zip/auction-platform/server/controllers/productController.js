const pool = require('../config/db');

const CATEGORIES = [
  'Electronics',
  'Art & Antiques',
  'Watches & Jewelry',
  'Collectibles',
  'Fashion',
  'Home & Garden',
];

async function listProducts(req, res) {
  try {
    const [rows] = await pool.query('SELECT * FROM products ORDER BY created_at DESC');
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch products' });
  }
}

async function listCategories(req, res) {
  res.json(CATEGORIES);
}

async function createProduct(req, res) {
  try {
    const { name, description, image_url, category, is_certified } = req.body;
    if (!name) return res.status(400).json({ error: 'name is required' });

    const [result] = await pool.query(
      'INSERT INTO products (name, description, image_url, category, is_certified, created_by) VALUES (?, ?, ?, ?, ?, ?)',
      [name, description || null, image_url || null, category || null, !!is_certified, req.user.id]
    );
    res.status(201).json({ id: result.insertId, name, description, image_url, category, is_certified: !!is_certified });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to create product' });
  }
}

async function updateProduct(req, res) {
  try {
    const { id } = req.params;
    const { name, description, image_url, category, is_certified } = req.body;
    const [result] = await pool.query(
      'UPDATE products SET name = ?, description = ?, image_url = ?, category = ?, is_certified = ? WHERE id = ?',
      [name, description || null, image_url || null, category || null, !!is_certified, id]
    );
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Product not found' });
    res.json({ id: Number(id), name, description, image_url, category, is_certified: !!is_certified });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to update product' });
  }
}

async function deleteProduct(req, res) {
  try {
    const { id } = req.params;
    const [result] = await pool.query('DELETE FROM products WHERE id = ?', [id]);
    if (result.affectedRows === 0) return res.status(404).json({ error: 'Product not found' });
    res.status(204).end();
  } catch (err) {
    if (err.errno === 1451) {
      return res.status(409).json({ error: 'This product has auctions and cannot be deleted' });
    }
    console.error(err);
    res.status(500).json({ error: 'Failed to delete product' });
  }
}

module.exports = { listProducts, listCategories, createProduct, updateProduct, deleteProduct, CATEGORIES };
