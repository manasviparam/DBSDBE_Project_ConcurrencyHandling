/**
 * Concurrency demo script for the project review.
 *
 * Fires many simultaneous bid requests (with distinct, increasing amounts)
 * at the SAME auction at nearly the SAME time, using pre-authenticated
 * test users. If concurrency control is working, exactly one final state
 * should be observed: the auction's current_highest_bid equals the
 * mathematical maximum of all submitted amounts, every accepted bid
 * appears in the bids table, and no bid was silently lost or overwritten.
 *
 * Usage:
 *   node test/concurrentBidTest.js <auctionId> <numConcurrentBids>
 *
 * Requires the server to be running and at least `numConcurrentBids`
 * distinct user accounts to exist (seed.sql provides 4 non-admin users;
 * extend seed data if you want more concurrent bidders).
 */
const axios = require('axios');

const BASE_URL = process.env.BASE_URL || 'http://localhost:5000/api';

const TEST_USERS = [
  { email: 'testuser@auction.com', password: 'password123' },
  { email: 'shravya@auction.com', password: 'password123' },
  { email: 'bidder1@auction.com', password: 'password123' },
  { email: 'bidder2@auction.com', password: 'password123' },
];

async function login(email, password) {
  const { data } = await axios.post(`${BASE_URL}/auth/login`, { email, password });
  return data.token;
}

async function main() {
  const auctionId = process.argv[2] || 1;
  const n = Math.min(Number(process.argv[3] || 4), TEST_USERS.length);

  console.log(`\nLogging in ${n} test users...`);
  const tokens = await Promise.all(
    TEST_USERS.slice(0, n).map((u) => login(u.email, u.password))
  );

  const { data: before } = await axios.get(`${BASE_URL}/auctions/${auctionId}`);
  console.log(`\nAuction ${auctionId} BEFORE test: current_highest_bid = ${before.current_highest_bid}`);

  const baseBid = Number(before.current_highest_bid) + 100;
  const amounts = tokens.map((_, i) => baseBid + i * 50); // distinct, increasing amounts
  const expectedMax = Math.max(...amounts);

  console.log(`\nFiring ${n} concurrent bids at auction ${auctionId}:`, amounts);

  const results = await Promise.allSettled(
    tokens.map((token, i) =>
      axios.post(
        `${BASE_URL}/auctions/${auctionId}/bids`,
        { amount: amounts[i] },
        { headers: { Authorization: `Bearer ${token}` } }
      )
    )
  );

  results.forEach((r, i) => {
    if (r.status === 'fulfilled') {
      console.log(`  Bid ${amounts[i]} -> accepted (bidId=${r.value.data.bidId})`);
    } else {
      console.log(`  Bid ${amounts[i]} -> rejected (${r.reason.response?.data?.error || r.reason.message})`);
    }
  });

  const { data: after } = await axios.get(`${BASE_URL}/auctions/${auctionId}`);
  const { data: history } = await axios.get(`${BASE_URL}/auctions/${auctionId}/bids`);

  console.log(`\nAuction ${auctionId} AFTER test: current_highest_bid = ${after.current_highest_bid}`);
  console.log(`Expected highest bid: ${expectedMax}`);
  console.log(`Bids recorded in history table: ${history.length}`);

  if (Number(after.current_highest_bid) === expectedMax) {
    console.log('\n✅ PASS: current_highest_bid matches the true maximum of concurrent bids. No lost update.');
  } else {
    console.log('\n❌ FAIL: current_highest_bid does NOT match expected maximum. Investigate transaction logic.');
  }
}

main().catch((err) => {
  console.error('Test script error:', err.response?.data || err.message);
  process.exit(1);
});
