const cron = require('node-cron');
const pool = require('../config/db');

/**
 * Closes a single auction (if still active) inside its own transaction,
 * records the result, and broadcasts `auction_closed`. Shared by the cron
 * sweep below and the admin "force close now" endpoint.
 */
async function closeAuctionById(auctionId, io) {
  const connection = await pool.getConnection();
  try {
    await connection.beginTransaction();

    const [rows] = await connection.query(
      `SELECT id, current_highest_bid, current_highest_bidder_id, status
       FROM auctions WHERE id = ? FOR UPDATE`,
      [auctionId]
    );
    if (rows.length === 0 || rows[0].status !== 'active') {
      await connection.rollback();
      return false;
    }
    const auction = rows[0];

    await connection.query(`UPDATE auctions SET status = 'closed' WHERE id = ?`, [auction.id]);

    let winningBidId = null;
    if (auction.current_highest_bidder_id) {
      const [bidRows] = await connection.query(
        `SELECT id FROM bids WHERE auction_id = ? ORDER BY amount DESC, created_at ASC LIMIT 1`,
        [auction.id]
      );
      winningBidId = bidRows[0]?.id || null;
    }

    await connection.query(
      `INSERT INTO auction_results (auction_id, winning_bid_id, winner_id)
       VALUES (?, ?, ?)
       ON DUPLICATE KEY UPDATE winning_bid_id = VALUES(winning_bid_id), winner_id = VALUES(winner_id)`,
      [auction.id, winningBidId, auction.current_highest_bidder_id]
    );

    await connection.commit();

    if (io) {
      io.emit('auction_closed', {
        auctionId: auction.id,
        winnerId: auction.current_highest_bidder_id,
        winningBid: auction.current_highest_bid,
      });
    }
    return true;
  } catch (err) {
    await connection.rollback();
    console.error(`Failed to close auction ${auctionId}:`, err);
    throw err;
  } finally {
    connection.release();
  }
}

async function closeExpiredAuctions(io) {
  const [expired] = await pool.query(
    `SELECT id FROM auctions WHERE status = 'active' AND end_time <= NOW()`
  );
  for (const auction of expired) {
    try {
      await closeAuctionById(auction.id, io);
    } catch {
      // already logged in closeAuctionById; keep sweeping the rest
    }
  }
}

/**
 * Promotes scheduled auctions to 'active' once their start_time has arrived
 * (and they haven't already ended). Without this, a scheduled auction would
 * never go live on its own.
 */
async function activateStartedAuctions(io) {
  const [due] = await pool.query(
    `SELECT id FROM auctions
     WHERE status = 'scheduled' AND start_time <= NOW() AND end_time > NOW()`
  );
  for (const auction of due) {
    const [result] = await pool.query(
      `UPDATE auctions SET status = 'active' WHERE id = ? AND status = 'scheduled'`,
      [auction.id]
    );
    if (result.affectedRows > 0 && io) io.emit('auction_started', { auctionId: auction.id });
  }
}

function startAuctionCloseJob(io) {
  // Runs every 30 seconds - frequent enough for a demo, cheap enough in general.
  cron.schedule('*/30 * * * * *', async () => {
    try {
      await activateStartedAuctions(io);
      await closeExpiredAuctions(io);
    } catch (err) {
      console.error('Auction sweep failed:', err);
    }
  });
}

module.exports = { startAuctionCloseJob, closeExpiredAuctions, closeAuctionById, activateStartedAuctions };
