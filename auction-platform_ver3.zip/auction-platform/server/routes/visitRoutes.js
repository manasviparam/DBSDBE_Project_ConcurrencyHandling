const express = require('express');
const router = express.Router();
const authenticate = require('../middleware/auth');
const { listMyVisits, scheduleVisit, cancelVisit } = require('../controllers/visitController');

router.get('/', authenticate, listMyVisits);
router.post('/:auctionId', authenticate, scheduleVisit);
router.delete('/:auctionId', authenticate, cancelVisit);

module.exports = router;
