const express = require('express');
const router = express.Router();
const authenticate = require('../middleware/auth');
const isAdmin = require('../middleware/isAdmin');
const { listProducts, listCategories, createProduct, updateProduct, deleteProduct } = require('../controllers/productController');

router.get('/', listProducts);
router.get('/categories', listCategories);
router.post('/', authenticate, isAdmin, createProduct);
router.put('/:id', authenticate, isAdmin, updateProduct);
router.delete('/:id', authenticate, isAdmin, deleteProduct);

module.exports = router;
