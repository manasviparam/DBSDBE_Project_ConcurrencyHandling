const express = require('express');
const router = express.Router();
const authenticate = require('../middleware/auth');
const { myBids, myWonAuctions } = require('../controllers/userController');

router.get('/me/bids', authenticate, myBids);
router.get('/me/won', authenticate, myWonAuctions);

module.exports = router;
