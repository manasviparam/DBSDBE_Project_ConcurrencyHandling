const express = require('express');
const router = express.Router();
const { optionalAuthenticate } = require('../middleware/auth');
const { getRecommendations } = require('../controllers/recommendationController');

router.get('/', optionalAuthenticate, getRecommendations);

module.exports = router;
