const express = require('express');
const router = express.Router();
const authenticate = require('../middleware/auth');
const isAdmin = require('../middleware/isAdmin');
const { listAuctions, getAuction, createAuction, updateAuction, closeAuctionNow, deleteAuction, getResult } = require('../controllers/auctionController');
const { placeBid, getBidHistory } = require('../controllers/bidController');

router.get('/', listAuctions);
router.get('/:id', getAuction);
router.post('/', authenticate, isAdmin, createAuction);
router.put('/:id', authenticate, isAdmin, updateAuction);
router.post('/:id/close', authenticate, isAdmin, closeAuctionNow);
router.delete('/:id', authenticate, isAdmin, deleteAuction);
router.get('/:id/result', getResult);

router.post('/:id/bids', authenticate, placeBid);
router.get('/:id/bids', getBidHistory);

module.exports = router;
