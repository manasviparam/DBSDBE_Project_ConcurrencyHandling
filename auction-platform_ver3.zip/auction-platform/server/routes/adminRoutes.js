const express = require('express');
const router = express.Router();
const authenticate = require('../middleware/auth');
const isAdmin = require('../middleware/isAdmin');
const { listUsers, listAllBids, updateUserRole, deleteUser, getStats, listPendingAuctions, setAuctionApproval } = require('../controllers/adminController');

router.get('/users', authenticate, isAdmin, listUsers);
router.patch('/users/:id/role', authenticate, isAdmin, updateUserRole);
router.delete('/users/:id', authenticate, isAdmin, deleteUser);
router.get('/bids', authenticate, isAdmin, listAllBids);
router.get('/stats', authenticate, isAdmin, getStats);
router.get('/auctions/pending', authenticate, isAdmin, listPendingAuctions);
router.patch('/auctions/:id/approval', authenticate, isAdmin, setAuctionApproval);

module.exports = router;
