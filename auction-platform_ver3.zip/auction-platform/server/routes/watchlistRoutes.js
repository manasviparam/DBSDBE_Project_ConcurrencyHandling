const express = require('express');
const router = express.Router();
const authenticate = require('../middleware/auth');
const { listWatchlist, addToWatchlist, removeFromWatchlist } = require('../controllers/watchlistController');

router.get('/', authenticate, listWatchlist);
router.post('/:auctionId', authenticate, addToWatchlist);
router.delete('/:auctionId', authenticate, removeFromWatchlist);

module.exports = router;
