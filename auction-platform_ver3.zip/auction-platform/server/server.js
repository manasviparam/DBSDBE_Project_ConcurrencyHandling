require('dotenv').config();
const http = require('http');
const { Server } = require('socket.io');

const app = require('./app');
const registerSocketHandlers = require('./sockets/index');
const { startAuctionCloseJob } = require('./jobs/closeAuctions');

process.on('unhandledRejection', (err) => console.error('Unhandled rejection:', err));
process.on('uncaughtException', (err) => console.error('Uncaught exception:', err));

const PORT = process.env.PORT || 5000;

const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: process.env.CLIENT_ORIGIN || '*' },
});

app.set('io', io);
registerSocketHandlers(io);
startAuctionCloseJob(io);

server.listen(PORT, () => {
  console.log(`Auction platform server running on port ${PORT}`);
});
