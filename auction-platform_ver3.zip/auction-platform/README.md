# Online Auction & Bidding Platform with Real-Time Concurrency Handling

Team 22 (Sec 7) — Param Manasvi, Ch. Shravya Chowdary

## Stack
React + Vite (frontend), Node.js + Express (backend), MySQL 8.0 / InnoDB, Socket.IO (real-time).

## 1. Set up the database

```bash
mysql -u root -p < server/schema.sql
mysql -u root -p < server/seed.sql
```

Seed users (all password: `password123`):
- admin@auction.com (admin)
- testuser@auction.com, shravya@auction.com, bidder1@auction.com, bidder2@auction.com (regular users)

Seed data: 24 products across 6 categories (4 each), each owned by a themed user —
shravya lists Art & Antiques, bidder2 lists Watches & Jewelry, testuser lists
Collectibles, bidder1 lists Home & Garden/furniture; admin keeps Electronics and
Fashion. Of the 24 auctions, most are `active`, 6 are `scheduled`, and only 2
(ids 4 and 12) are `closed` with a finalized result. 4 more items are listed by
users but sit in `pending` verification, awaiting admin sign-off in the
Approvals tab before they're visible to shoppers (see below).

## 2. Run the backend

```bash
cd server
cp .env.example .env      # edit DB_PASSWORD and JWT_SECRET
npm install
npm run dev                # nodemon server.js, listens on PORT (default 5000)
```

Health check: `GET http://localhost:5000/api/health` → `{ "status": "ok" }`

## 3. Run the frontend

```bash
cd client
cp .env.example .env
npm install
npm run dev                # Vite dev server on http://localhost:5173
```

Open http://localhost:5173, register a new account or log in with a seeded user, browse auctions, open one, and place a bid. Open the same auction in a second browser tab/window logged in as a different user to see live bid updates via Socket.IO.

## 4. Prove the concurrency handling (for the review)

This is the part the panel will care about most. With the backend running:

```bash
cd server
npm run test:concurrency -- 1 4
# args: <auctionId> <numConcurrentBids>
```

This logs in 4 seeded users and fires 4 simultaneous bids (distinct increasing amounts) at auction 1 using `Promise.allSettled`. It then confirms that `current_highest_bid` in the database equals the true maximum of the submitted bids and that every bid appears in the `bids` history table — demonstrating that the `SELECT ... FOR UPDATE` row lock + single transaction prevents the lost-update race condition described in the abstract (see slide "PROBLEM" in the PPT).

You can also just open the MySQL client and watch:
```sql
SELECT current_highest_bid, current_highest_bidder_id FROM auctions WHERE id = 1;
SELECT * FROM bids WHERE auction_id = 1 ORDER BY created_at;
```

## 5. How the concurrency fix works (talking points for the panel)

1. Each bid request begins a MySQL transaction.
2. `SELECT current_highest_bid ... FOR UPDATE` takes a row lock on that auction — any other concurrent transaction bidding on the same auction blocks until this one commits or rolls back.
3. The bid is validated against the *locked* value (not a stale read).
4. `UPDATE auctions ...` and `INSERT INTO bids ...` happen in the same transaction, then `COMMIT` releases the lock.
5. InnoDB's default `REPEATABLE READ` isolation, combined with the explicit row lock, closes the classic read-check-write race window.
6. If MySQL reports a deadlock (`ER_LOCK_DEADLOCK`), the request is automatically retried with jittered backoff (see `controllers/bidController.js`).
7. A background cron job (`node-cron`, every 30s) closes auctions whose `end_time` has passed and records the winner in `auction_results`.

See `controllers/bidController.js` — the entire mechanism is in `placeBidTransaction()`.

## 6. Item verification (admin approval)

Every auction has an `approval_status` (`pending` / `approved` / `rejected`), separate
from its `status` (`scheduled` / `active` / `closed`). Admin-created auctions default to
`approved`; the 4 seeded items owned by non-admin users (`shravya`, `bidder1`, `bidder2`,
`testuser`) start as `pending` and are hidden from the public storefront until an admin
authorises them. Log in as `admin@auction.com`, open the **Approvals** tab in the Admin
Control Center, and Authorise or Reject each item — approving makes it show up in the
regular auction listing/filters immediately.

## Project structure

```
server/
  schema.sql, seed.sql         -- DB schema + sample data
  config/db.js                 -- MySQL connection pool
  controllers/                 -- business logic (bidController.js is the core piece)
  middleware/                  -- JWT auth, admin guard
  routes/                      -- Express route definitions
  sockets/                     -- Socket.IO room join/leave handlers
  jobs/closeAuctions.js        -- cron job to auto-close expired auctions
  test/concurrentBidTest.js    -- concurrency demo/proof script
  app.js, server.js            -- Express + HTTP + Socket.IO bootstrap

client/
  src/pages/                   -- Login, Register, AuctionList, AuctionDetail, AdminDashboard
  src/components/              -- AuctionCard, BidForm, BidHistoryTable
  src/context/                 -- AuthContext (JWT), SocketContext
  src/api/axios.js             -- API client with auth header injection
```

## What's intentionally minimal (given the review timeline)

- No payment integration (flagged as future scope in the abstract).
- Styling is functional, not polished — prioritize the concurrency demo and core flow for review 1.

## 7. Expo day (3 Oct 2026, ends by 16:00 IST)

- `npm run refresh:expo` (in `server/`) updates the existing DB in place: the expo auctions (incl. revived 4 and 12)
  go **live now** with staggered end times (all by 16:00 IST, or now + 30..115 min if that time has passed), stale
  winner rows are removed and venues from `server/data/venues.json` are applied. Users, bids, watchlist, visits and
  pending items are untouched. It also sets realistic INR starting prices (scaling existing bids to match) and
  moves the upcoming items to this evening. Safe to re-run.
- The cron job also promotes `scheduled` auctions to `active` when their start time arrives.
- DB sessions use `Asia/Kolkata` (+05:30).
- Live Auctions: each row has a **Directions** button (OpenStreetMap + OSRM routing; falls back to a typed
  starting address if location permission is denied). Venues are per auction (`venue_name`, `venue_address`,
  `venue_lat`/`venue_lng`) - the current ones are sample Hyderabad landmarks.
- A rule-based help chatbot floats on every page (`client/src/components/Chatbot.jsx`).
