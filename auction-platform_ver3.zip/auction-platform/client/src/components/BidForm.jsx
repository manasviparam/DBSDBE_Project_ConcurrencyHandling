import { useState } from 'react';
import api from '../api/axios';
import { useAuth } from '../context/AuthContext';

export default function BidForm({ auction, onBidPlaced }) {
  const [amount, setAmount] = useState('');
  const [error, setError] = useState('');
  const [submitting, setSubmitting] = useState(false);
  const { user } = useAuth();

  async function submitAmount(value) {
    setError('');
    setSubmitting(true);
    try {
      await api.post(`/auctions/${auction.id}/bids`, { amount: Number(value) });
      setAmount('');
      onBidPlaced?.();
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to place bid');
    } finally {
      setSubmitting(false);
    }
  }

  function handleSubmit(e) {
    e.preventDefault();
    submitAmount(amount);
  }

  if (!user) return <p>Please log in to place a bid.</p>;
  if (auction.status !== 'active') return <p>This auction is not currently active.</p>;

  const current = Number(auction.current_highest_bid);
  const quick5 = Math.ceil(current * 1.05);
  const quick10 = Math.ceil(current * 1.1);

  return (
    <div>
      <div className="quick-bid-row">
        <button type="button" className="secondary" disabled={submitting} onClick={() => submitAmount(quick5)}>
          +5% (₹{quick5})
        </button>
        <button type="button" className="secondary" disabled={submitting} onClick={() => submitAmount(quick10)}>
          +10% (₹{quick10})
        </button>
      </div>
      <form onSubmit={handleSubmit} className="bid-form">
        <input
          type="number"
          step="0.01"
          placeholder={`More than ₹${auction.current_highest_bid}`}
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          required
        />
        <button type="submit" disabled={submitting}>
          {submitting ? 'Placing...' : 'Place Bid'}
        </button>
      </form>
      {error && <p className="error">{error}</p>}
    </div>
  );
}
