import { useTicker } from '../hooks/useTicker';
import { IconClock } from './Icons';

const WEEK_MS = 7 * 24 * 60 * 60 * 1000;
const DAY_MS = 24 * 60 * 60 * 1000;

function formatDuration(ms) {
  const totalSeconds = Math.max(0, Math.floor(ms / 1000));
  const days = Math.floor(totalSeconds / 86400);
  const hours = Math.floor((totalSeconds % 86400) / 3600);
  const minutes = Math.floor((totalSeconds % 3600) / 60);
  const seconds = totalSeconds % 60;
  if (days > 0) return `${days}d ${hours}h`;
  if (hours > 0) return `${hours}h ${minutes}m`;
  return `${minutes}m ${seconds}s`;
}

function formatApprox(ms) {
  const days = ms / DAY_MS;
  if (days < 60) {
    const weeks = Math.max(1, Math.round(days / 7));
    return `~${weeks} week${weeks === 1 ? '' : 's'}`;
  }
  const months = Math.round(days / 30);
  return `~${months} month${months === 1 ? '' : 's'}`;
}

export default function CountdownTimer({ startTime, endTime, status }) {
  useTicker();
  const now = Date.now();

  if (status === 'closed') {
    return <span className="countdown"><IconClock width={13} height={13} /> Ended</span>;
  }

  if (status === 'scheduled') {
    const remaining = new Date(startTime).getTime() - now;
    if (remaining <= 0) {
      return <span className="countdown"><IconClock width={13} height={13} /> Starting now</span>;
    }
    if (remaining <= WEEK_MS) {
      return <span className="countdown"><IconClock width={13} height={13} /> Starts in {formatDuration(remaining)}</span>;
    }
    return <span className="countdown"><IconClock width={13} height={13} /> Starts in {formatApprox(remaining)}</span>;
  }

  const remaining = new Date(endTime).getTime() - now;
  const urgent = remaining > 0 && remaining < 5 * 60 * 1000;

  return (
    <span className={`countdown${urgent ? ' urgent' : ''}`}>
      <IconClock width={13} height={13} /> {remaining <= 0 ? 'Ended' : `${formatDuration(remaining)} left`}
    </span>
  );
}
