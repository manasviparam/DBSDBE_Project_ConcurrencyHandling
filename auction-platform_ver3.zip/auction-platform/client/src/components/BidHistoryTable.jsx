import { motion } from 'framer-motion';

export default function BidHistoryTable({ bids }) {
  if (!bids.length) return <p style={{ color: 'var(--text-muted)' }}>No bids placed yet. Be the first!</p>;

  const topAmount = Math.max(...bids.map((b) => Number(b.amount)));

  return (
    <div className="data-table-wrap glass">
      <table className="bid-history">
        <thead>
          <tr>
            <th>Bidder</th>
            <th>Amount</th>
            <th>Time</th>
          </tr>
        </thead>
        <tbody>
          {bids.map((b) => (
            <motion.tr
              key={b.id}
              className={Number(b.amount) === topAmount ? 'top-bid' : ''}
              initial={{ opacity: 0, x: -8 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.25 }}
            >
              <td>{b.bidder_name}</td>
              <td>₹{Number(b.amount).toLocaleString('en-IN')}</td>
              <td>{new Date(b.created_at).toLocaleTimeString()}</td>
            </motion.tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
