import { IconSparkle, IconLaptop, IconPalette, IconGem, IconArchive, IconBag, IconHome } from './Icons';

const ICONS = {
  'Electronics': IconLaptop,
  'Art & Antiques': IconPalette,
  'Watches & Jewelry': IconGem,
  'Collectibles': IconArchive,
  'Fashion': IconBag,
  'Home & Garden': IconHome,
};

export default function CategoryTiles({ categories, active, onSelect }) {
  return (
    <div className="category-tiles">
      <div
        className={`category-tile glass${!active ? ' active' : ''}`}
        onClick={() => onSelect(null)}
      >
        <span className="icon"><IconSparkle width={22} height={22} /></span>
        All
      </div>
      {categories.map((c) => {
        const Icon = ICONS[c] || IconArchive;
        return (
          <div
            key={c}
            className={`category-tile glass${active === c ? ' active' : ''}`}
            onClick={() => onSelect(c)}
          >
            <span className="icon"><Icon width={22} height={22} /></span>
            {c}
          </div>
        );
      })}
    </div>
  );
}
