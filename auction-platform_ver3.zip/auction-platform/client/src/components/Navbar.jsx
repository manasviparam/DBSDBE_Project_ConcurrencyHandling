import { useState } from 'react';
import { Link, NavLink, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useTheme } from '../context/ThemeContext';
import { useNotifications } from '../context/NotificationContext';
import { IconLock, IconSearch, IconBell } from './Icons';

export default function Navbar() {
  const { user, logout } = useAuth();
  const { toggleTheme } = useTheme();
  const notif = useNotifications();
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [bellOpen, setBellOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  function handleSearch(e) {
    e.preventDefault();
    navigate(`/auctions?search=${encodeURIComponent(search)}`);
  }

  return (
    <div className="navbar">
      <div className="navbar-inner">
        <Link to="/auctions" className="brand">
          <span className="brand-mark"><IconLock width={17} height={17} stroke="white" /></span>
          Vault
        </Link>

        <form className="nav-search glass" onSubmit={handleSearch}>
          <IconSearch width={16} height={16} className="icon-muted" />
          <input
            placeholder="Search auctions, categories..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </form>

        <div className="nav-links">
          <NavLink to="/auctions" className={({ isActive }) => (isActive ? 'active' : '')}>Auctions</NavLink>
          <NavLink to="/live-auctions" className={({ isActive }) => (isActive ? 'active' : '')}>Live Auctions</NavLink>
          <NavLink to="/recommendations" className={({ isActive }) => (isActive ? 'active' : '')}>For You</NavLink>
          {user?.role === 'admin' && (
            <NavLink to="/admin" className={({ isActive }) => (isActive ? 'active' : '')}>Admin</NavLink>
          )}

          <button className="theme-toggle" onClick={toggleTheme} title="Toggle theme" aria-label="Toggle theme">
            <span className="theme-toggle-knob" />
          </button>

          {user && (
            <div className="bell-wrap">
              <button className="icon-btn" onClick={() => { setBellOpen((o) => !o); setMenuOpen(false); notif?.markAllRead(); }}>
                <IconBell width={17} height={17} />
                {notif?.unreadCount > 0 && <span className="badge-dot">{notif.unreadCount}</span>}
              </button>
              {bellOpen && (
                <div className="dropdown glass">
                  {!notif?.notifications.length && <div className="dropdown-item">No notifications yet.</div>}
                  {notif?.notifications.map((n) => (
                    <div className="dropdown-item" key={n.id} onClick={() => { navigate(`/auctions/${n.auctionId}`); setBellOpen(false); }}>
                      {n.message}
                      <span className="time">{new Date(n.time).toLocaleTimeString()}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}

          {user ? (
            <div className="avatar-menu-wrap">
              <button className="avatar" onClick={() => { setMenuOpen((o) => !o); setBellOpen(false); }}>
                {user.name.slice(0, 1).toUpperCase()}
              </button>
              {menuOpen && (
                <div className="dropdown glass menu-list" style={{ width: 200 }}>
                  <Link to="/activity" onClick={() => setMenuOpen(false)}>My Activity</Link>
                  <Link to="/watchlist" onClick={() => setMenuOpen(false)}>Watchlist</Link>
                  {user.role === 'admin' && <Link to="/admin" onClick={() => setMenuOpen(false)}>Admin Panel</Link>}
                  <button onClick={logout}>Logout</button>
                </div>
              )}
            </div>
          ) : (
            <>
              <Link to="/login">Login</Link>
              <Link to="/register">Register</Link>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
