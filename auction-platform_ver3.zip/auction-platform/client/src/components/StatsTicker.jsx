import { useEffect, useState } from 'react';
import api from '../api/axios';

export default function StatsTicker() {
  const [auctions, setAuctions] = useState(null);

  useEffect(() => {
    let mounted = true;
    function load() {
      api.get('/auctions').then((res) => mounted && setAuctions(res.data));
    }
    load();
    const t = setInterval(load, 30000);
    return () => { mounted = false; clearInterval(t); };
  }, []);

  if (!auctions) return null;

  const active = auctions.filter((a) => a.status === 'active').length;
  const totalBidValue = auctions
    .filter((a) => a.status === 'active')
    .reduce((sum, a) => sum + Number(a.current_highest_bid), 0);
  const endingSoon = auctions.filter((a) => {
    if (a.status !== 'active') return false;
    const remaining = new Date(a.end_time).getTime() - Date.now();
    return remaining > 0 && remaining < 60 * 60 * 1000;
  }).length;

  return (
    <div className="stats-ticker">
      <div className="stat-chip glass">
        <div className="value">{active}</div>
        <div className="label">Live Auctions</div>
      </div>
      <div className="stat-chip glass">
        <div className="value">{endingSoon}</div>
        <div className="label">Ending Soon</div>
      </div>
      <div className="stat-chip glass">
        <div className="value">₹{totalBidValue.toLocaleString('en-IN')}</div>
        <div className="label">Live Bid Value</div>
      </div>
    </div>
  );
}
