import { useEffect, useRef, useState } from 'react';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import { IconClose, IconMapPin } from './Icons';

// Free, key-less services: OpenStreetMap tiles, Nominatim (geocoding), OSRM (routing).
async function geocode(query) {
  const url = `https://nominatim.openstreetmap.org/search?format=json&limit=1&countrycodes=in&q=${encodeURIComponent(query)}`;
  const res = await fetch(url, { headers: { Accept: 'application/json' } });
  if (!res.ok) throw new Error('Address lookup failed');
  const data = await res.json();
  if (!data.length) throw new Error('Could not find that address');
  return { lat: Number(data[0].lat), lng: Number(data[0].lon) };
}

async function fetchRoute(from, to) {
  const url = `https://router.project-osrm.org/route/v1/driving/${from.lng},${from.lat};${to.lng},${to.lat}?overview=full&geometries=geojson`;
  const res = await fetch(url);
  if (!res.ok) throw new Error('Routing service unavailable');
  const data = await res.json();
  if (data.code !== 'Ok' || !data.routes?.length) throw new Error('No driving route found between these points');
  return data.routes[0];
}

function formatDistance(m) {
  return m >= 1000 ? `${(m / 1000).toFixed(1)} km` : `${Math.round(m)} m`;
}

function formatDuration(s) {
  const mins = Math.max(1, Math.round(s / 60));
  if (mins < 60) return `${mins} min`;
  const h = Math.floor(mins / 60);
  return `${h} h ${mins % 60} min`;
}

export default function DirectionsModal({ auction, onClose }) {
  const mapEl = useRef(null);
  const map = useRef(null);
  const layers = useRef([]);
  const [stage, setStage] = useState('locating'); // locating | need-address | routing | done
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [typed, setTyped] = useState('');
  const [summary, setSummary] = useState(null);
  const [dest, setDest] = useState(null);

  const venueLabel = [auction.venue_name, auction.venue_address].filter(Boolean).join(' — ');

  // map lifecycle
  useEffect(() => {
    map.current = L.map(mapEl.current, { zoomControl: true }).setView([20.5937, 78.9629], 5);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; OpenStreetMap contributors',
    }).addTo(map.current);
    setTimeout(() => map.current?.invalidateSize(), 50);
    return () => { map.current?.remove(); map.current = null; };
  }, []);

  // resolve the destination once, then ask for the user's location
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        let d;
        if (auction.venue_lat != null && auction.venue_lng != null) {
          d = { lat: Number(auction.venue_lat), lng: Number(auction.venue_lng) };
        } else {
          d = await geocode([auction.venue_name, auction.venue_address].filter(Boolean).join(', '));
        }
        if (cancelled) return;
        setDest(d);
        L.marker([d.lat, d.lng]).addTo(map.current).bindPopup(auction.venue_name || 'Venue');
        map.current.setView([d.lat, d.lng], 14);
        locate(d);
      } catch (err) {
        if (!cancelled) setError(err.message || 'Could not find the venue on the map');
      }
    })();
    return () => { cancelled = true; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function clearLayers() {
    layers.current.forEach((l) => l.remove());
    layers.current = [];
  }

  async function drawRoute(from, to) {
    setStage('routing');
    setError('');
    try {
      const route = await fetchRoute(from, to);
      if (!map.current) return;
      clearLayers();
      const start = L.circleMarker([from.lat, from.lng], { radius: 8, color: '#fff', weight: 2, fillColor: '#1f6feb', fillOpacity: 1 })
        .addTo(map.current).bindPopup('You are here');
      const line = L.geoJSON(route.geometry, { style: { color: '#1f3a5f', weight: 5, opacity: 0.85 } }).addTo(map.current);
      layers.current.push(start, line);
      map.current.fitBounds(line.getBounds(), { padding: [30, 30] });
      setSummary({ distance: route.distance, duration: route.duration });
      setStage('done');
    } catch (err) {
      setError(err.message || 'Could not get directions');
      setStage('need-address');
    }
  }

  function locate(d = dest) {
    setError('');
    if (!navigator.geolocation) {
      setMessage('Your browser does not support location access.');
      setStage('need-address');
      return;
    }
    setStage('locating');
    navigator.geolocation.getCurrentPosition(
      (pos) => drawRoute({ lat: pos.coords.latitude, lng: pos.coords.longitude }, d),
      (err) => {
        setMessage(err.code === 1
          ? 'Location permission was denied. Enter your starting address instead.'
          : 'Could not detect your location. Enter your starting address instead.');
        setStage('need-address');
      },
      { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 }
    );
  }

  async function useTypedAddress(e) {
    e.preventDefault();
    if (!typed.trim() || !dest) return;
    setError('');
    setStage('routing');
    try {
      const from = await geocode(typed.trim());
      await drawRoute(from, dest);
    } catch (err) {
      setError(err.message);
      setStage('need-address');
    }
  }

  return (
    <div className="modal-backdrop" onClick={onClose}>
      <div className="modal-card glass" onClick={(e) => e.stopPropagation()}>
        <div className="modal-head">
          <div style={{ minWidth: 0 }}>
            <h3 style={{ margin: 0, display: 'flex', alignItems: 'center', gap: 6 }}>
              <IconMapPin width={17} height={17} /> Directions
            </h3>
            <div className="modal-sub">{auction.product_name}{venueLabel ? ` · ${venueLabel}` : ''}</div>
          </div>
          <button className="ghost icon-btn" onClick={onClose} aria-label="Close"><IconClose width={16} height={16} /></button>
        </div>

        {summary && (
          <div className="route-summary">
            <div><span>Distance</span><strong>{formatDistance(summary.distance)}</strong></div>
            <div><span>Drive time</span><strong>{formatDuration(summary.duration)}</strong></div>
          </div>
        )}
        {stage === 'locating' && !error && <p className="modal-note">Waiting for your location… please allow access in the browser prompt.</p>}
        {stage === 'routing' && <p className="modal-note">Finding the best route…</p>}
        {error && <p className="error" style={{ margin: '8px 0' }}>{error}</p>}

        {stage === 'need-address' && dest && (
          <form onSubmit={useTypedAddress} className="modal-form">
            {message && <p className="modal-note" style={{ margin: 0 }}>{message}</p>}
            <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
              <input
                type="text"
                placeholder="Your starting address (e.g. area, city)"
                value={typed}
                onChange={(e) => setTyped(e.target.value)}
                style={{ flex: 1, minWidth: 200 }}
              />
              <button type="submit">Get route</button>
              <button type="button" className="secondary" onClick={() => locate()}>Use my location</button>
            </div>
          </form>
        )}

        <div ref={mapEl} className="map-box" />
      </div>
    </div>
  );
}
