import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';

export default function FeaturedCarousel({ auctions }) {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    if (auctions.length < 2) return;
    const t = setInterval(() => setIndex((i) => (i + 1) % auctions.length), 5000);
    return () => clearInterval(t);
  }, [auctions.length]);

  if (!auctions.length) return null;
  const a = auctions[index % auctions.length];

  return (
    <div className="carousel glass">
      <AnimatePresence mode="wait">
        <motion.div
          key={a.id}
          className="carousel-slide"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
        >
          <img src={a.image_url} alt={a.product_name} />
          <div className="carousel-slide-info">
            <span className="tag">Featured</span>
            <h3>{a.product_name}</h3>
            <p style={{ margin: 0, opacity: 0.85, fontSize: 14 }}>
              Current bid: ₹{a.current_highest_bid}
            </p>
            <Link to={`/auctions/${a.id}`}>
              <button>View Auction</button>
            </Link>
          </div>
        </motion.div>
      </AnimatePresence>
      <div className="carousel-dots">
        {auctions.map((item, i) => (
          <button
            key={item.id}
            className={i === index ? 'active' : ''}
            onClick={() => setIndex(i)}
          />
        ))}
      </div>
    </div>
  );
}
