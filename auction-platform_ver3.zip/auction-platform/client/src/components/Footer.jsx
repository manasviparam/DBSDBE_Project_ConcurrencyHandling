export default function Footer() {
  return (
    <div className="footer">
      <div className="container footer-inner">
        <span>© {new Date().getFullYear()} Vault — Online Auction & Bidding Platform</span>
        <span>Built with React, Express, MySQL & Socket.IO</span>
      </div>
    </div>
  );
}
