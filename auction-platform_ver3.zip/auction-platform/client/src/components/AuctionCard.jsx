import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import CountdownTimer from './CountdownTimer';
import { useAuth } from '../context/AuthContext';
import { IconHeart, IconShieldCheck, IconUsers } from './Icons';

export default function AuctionCard({ auction, watched, onToggleWatch }) {
  const { user } = useAuth();

  return (
    <motion.div
      className="card glass"
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <div className="card-image">
        <img src={auction.image_url || 'https://picsum.photos/seed/fallback/700/500'} alt={auction.product_name} loading="lazy" />
        <div className="card-badges">
          {auction.category && <span className="category-badge">{auction.category}</span>}
          {auction.is_certified ? (
            <span className="category-badge certified-badge" title="Certified authentic">
              <IconShieldCheck width={10} height={10} />
            </span>
          ) : null}
        </div>
        {user && (
          <button
            className={`watch-btn${watched ? ' active' : ''}`}
            onClick={(e) => { e.preventDefault(); onToggleWatch?.(auction.id); }}
            title={watched ? 'Remove from watchlist' : 'Add to watchlist'}
          >
            <IconHeart width={13} height={13} filled={watched} />
          </button>
        )}
      </div>
      <div className="card-body">
        <Link to={`/auctions/${auction.id}`} className="title-link">
          <h3>{auction.product_name}</h3>
        </Link>
        <p className="card-desc">{auction.product_description}</p>
        <div className="card-meta-row">
          <span className="bidder-count" title={`${auction.bidder_count || 0} bidder${Number(auction.bidder_count) === 1 ? '' : 's'}`}>
            <IconUsers width={11} height={11} /> {auction.bidder_count || 0}
          </span>
          <CountdownTimer startTime={auction.start_time} endTime={auction.end_time} status={auction.status} />
        </div>
        <div className="card-price-row">
          <div className="card-price">
            <span className="label">Current bid</span>
            ₹{Number(auction.current_highest_bid).toLocaleString('en-IN')}
          </div>
          <span className={`status status-${auction.status}`}>{auction.status}</span>
        </div>
        <Link to={`/auctions/${auction.id}`}><button className="card-cta">View &amp; Bid</button></Link>
      </div>
    </motion.div>
  );
}
