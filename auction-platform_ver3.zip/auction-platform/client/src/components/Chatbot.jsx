import { useEffect, useRef, useState } from 'react';
import api from '../api/axios';
import { IconChat, IconClose, IconSend } from './Icons';

// Expo details - edit here if the timings change.
const EXPO = { date: '3 October 2026', time: '12:00 PM – 4:00 PM IST' };

// Rule-based knowledge base: the first entry whose keywords score highest wins.
const KB = [
  {
    keys: ['hi', 'hello', 'hey', 'help', 'start'],
    answer: 'Hi! I can help with bidding, the expo timings, finding a venue, scheduling a visit, your watchlist and more. Pick a topic below or just type your question.',
  },
  {
    keys: ['expo', 'timing', 'timings', 'time', 'open', 'hours', 'when', 'date', 'schedule of expo'],
    answer: `The expo runs on ${EXPO.date}, ${EXPO.time}. Items go live at 12:00 PM and close at staggered times, all by 4:00 PM. Each auction's end time is shown on its card.`,
  },
  {
    keys: ['bid', 'bidding', 'place', 'how to bid', 'raise', 'offer'],
    answer: 'To bid: log in, open an auction that is live, enter an amount higher than the current highest bid and press Place Bid. You can also use the +5% / +10% quick-bid buttons. A bid is accepted only if it beats the current highest bid at the moment it is processed.',
  },
  {
    keys: ['reject', 'rejected', 'failed', 'higher', 'outbid', 'lost', 'not accepted', 'error', 'simultaneous', 'same time'],
    answer: 'If your bid was rejected, someone probably bid higher a moment earlier. Bids are processed one at a time per auction (database row locking), so the higher valid bid always wins. Check the new highest bid and try again.',
  },
  {
    keys: ['directions', 'direction', 'map', 'route', 'location', 'venue', 'where', 'address', 'reach', 'navigate', 'distance'],
    answer: 'Go to Live Auctions and press "Directions" on the item. Allow location access to see the route and distance from where you are. If you deny it, you can type a starting address instead. Each item can have a different venue, so check the one on the item you want.',
  },
  {
    keys: ['visit', 'schedule a visit', 'book', 'reserve', 'slot'],
    answer: 'On the Live Auctions page press "Schedule a Visit" on an item, pick a date and time and confirm. Your scheduled visits are listed at the top of that page, and you can cancel them there.',
  },
  {
    keys: ['live', 'live now', 'happening', 'upcoming', 'scheduled', 'start'],
    answer: 'Live Auctions (top menu) shows what is happening now and what is coming up. Upcoming items go live automatically when their start time arrives.',
    dynamic: 'live',
  },
  {
    keys: ['ending', 'ends', 'end soon', 'closing', 'deadline', 'last'],
    answer: 'Here is what is closing next:',
    dynamic: 'ending',
  },
  {
    keys: ['win', 'winner', 'won', 'result', 'highest bidder', 'after auction'],
    answer: 'When an auction ends, the highest valid bidder is recorded as the winner automatically. See your wins under My Activity → Auctions Won.',
  },
  {
    keys: ['register', 'signup', 'sign up', 'account', 'login', 'log in', 'password'],
    answer: 'Use Register (top right) to create an account, or Login if you already have one. You need to be logged in to bid, use the watchlist and schedule visits.',
  },
  {
    keys: ['watchlist', 'watch', 'save', 'favourite', 'favorite', 'heart'],
    answer: 'Tap the heart on an auction card to add it to your Watchlist. Open it from your profile menu to track those items.',
  },
  {
    keys: ['pending', 'approval', 'approve', 'verification', 'verify', 'authorised', 'authorized', 'not visible', 'hidden'],
    answer: 'Items listed by users are verified by an admin before they appear in the auction list. Pending items become visible once the admin authorises them.',
  },
  {
    keys: ['certified', 'authentic', 'genuine', 'badge'],
    answer: 'Items with the certified badge have been checked as authentic by the platform.',
  },
  {
    keys: ['recommend', 'recommendation', 'for you', 'suggest'],
    answer: 'The "For You" page suggests auctions based on your activity and interests.',
  },
  {
    keys: ['activity', 'history', 'my bids', 'bids placed'],
    answer: 'My Activity (profile menu) lists the bids you have placed and the auctions you have won.',
  },
  {
    keys: ['pay', 'payment', 'paid', 'checkout', 'refund', 'money'],
    answer: 'Online payments are not part of the platform yet. Please ask the expo staff about payment for won items.',
  },
  {
    keys: ['admin', 'manage', 'create auction', 'add product'],
    answer: 'Admins can manage users, products, auctions, bids and approvals from the Admin Control Center (Admin in the menu).',
  },
  {
    keys: ['thanks', 'thank', 'thx', 'ok', 'great'],
    answer: "You're welcome! Anything else I can help with?",
  },
];

const SUGGESTIONS = ['Expo timings', 'How do I bid?', 'Get directions', "What's live now?", 'Schedule a visit'];

function normalize(t) {
  return t.toLowerCase().replace(/[^a-z0-9\s]/g, ' ').replace(/\s+/g, ' ').trim();
}

function findEntry(text) {
  const q = ` ${normalize(text)} `;
  let best = null;
  let bestScore = 0;
  for (const entry of KB) {
    let score = 0;
    for (const k of entry.keys) {
      if (q.includes(` ${k} `)) score += k.includes(' ') ? 2 : 1;
    }
    if (score > bestScore) { best = entry; bestScore = score; }
  }
  return best;
}

async function liveAuctions() {
  const { data } = await api.get('/auctions');
  return data.filter((a) => a.status === 'active' && a.approval_status !== 'pending' && a.approval_status !== 'rejected');
}

async function answerFor(text) {
  const entry = findEntry(text);
  if (!entry) {
    return "Sorry, I didn't catch that. I can help with bidding, expo timings, directions to a venue, scheduling a visit, winners, your account and the watchlist. Try one of the topics below.";
  }
  if (!entry.dynamic) return entry.answer;
  try {
    const live = await liveAuctions();
    if (entry.dynamic === 'live') {
      return `${entry.answer}\n\nRight now ${live.length} auction${live.length === 1 ? ' is' : 's are'} live.`;
    }
    if (live.length === 0) return 'No auctions are live at the moment.';
    const soon = [...live].sort((a, b) => new Date(a.end_time) - new Date(b.end_time)).slice(0, 3);
    const fmt = (d) => new Date(d).toLocaleTimeString('en-IN', { hour: 'numeric', minute: '2-digit', timeZone: 'Asia/Kolkata' });
    return `${entry.answer}\n${soon.map((a) => `• ${a.product_name} — ends ${fmt(a.end_time)}`).join('\n')}`;
  } catch {
    return entry.answer;
  }
}

export default function Chatbot() {
  const [open, setOpen] = useState(false);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [messages, setMessages] = useState([
    { from: 'bot', text: 'Hi! I\'m the Vault assistant. Ask me anything about the auctions or the expo.' },
  ]);
  const endRef = useRef(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, open]);

  async function send(text) {
    const value = text.trim();
    if (!value || busy) return;
    setMessages((m) => [...m, { from: 'user', text: value }]);
    setInput('');
    setBusy(true);
    const reply = await answerFor(value);
    setMessages((m) => [...m, { from: 'bot', text: reply }]);
    setBusy(false);
  }

  return (
    <>
      {open && (
        <div className="chatbot-panel glass" role="dialog" aria-label="Help chat">
          <div className="chatbot-head">
            <strong>Vault Assistant</strong>
            <button className="ghost icon-btn" onClick={() => setOpen(false)} aria-label="Close chat">
              <IconClose width={16} height={16} />
            </button>
          </div>
          <div className="chatbot-body">
            {messages.map((m, i) => (
              <div key={i} className={`chat-msg ${m.from}`}>{m.text}</div>
            ))}
            {busy && <div className="chat-msg bot">…</div>}
            <div ref={endRef} />
          </div>
          <div className="chatbot-chips">
            {SUGGESTIONS.map((s) => (
              <button key={s} type="button" className="chip-btn" onClick={() => send(s)}>{s}</button>
            ))}
          </div>
          <form className="chatbot-input" onSubmit={(e) => { e.preventDefault(); send(input); }}>
            <input
              type="text"
              placeholder="Type your question…"
              value={input}
              onChange={(e) => setInput(e.target.value)}
            />
            <button type="submit" disabled={busy || !input.trim()} aria-label="Send"><IconSend width={16} height={16} /></button>
          </form>
        </div>
      )}
      <button className="chatbot-fab" onClick={() => setOpen((o) => !o)} aria-label={open ? 'Close help chat' : 'Open help chat'}>
        {open ? <IconClose width={22} height={22} /> : <IconChat width={22} height={22} />}
      </button>
    </>
  );
}
