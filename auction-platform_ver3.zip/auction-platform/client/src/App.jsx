import { BrowserRouter, Routes, Route, Navigate, useLocation } from 'react-router-dom';
import { AnimatePresence, motion } from 'framer-motion';
import { Toaster } from 'react-hot-toast';
import { AuthProvider, useAuth } from './context/AuthContext';
import { SocketProvider } from './context/SocketContext';
import { ThemeProvider } from './context/ThemeContext';
import { NotificationProvider } from './context/NotificationContext';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import Login from './pages/Login';
import Register from './pages/Register';
import AuctionList from './pages/AuctionList';
import AuctionDetail from './pages/AuctionDetail';
import AdminDashboard from './pages/AdminDashboard';
import Watchlist from './pages/Watchlist';
import MyActivity from './pages/MyActivity';
import Recommendations from './pages/Recommendations';
import LiveAuctions from './pages/LiveAuctions';
import Chatbot from './components/Chatbot';

function PrivateRoute({ children }) {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" />;
  return children;
}

function PrivateAdminRoute({ children }) {
  const { user } = useAuth();
  if (!user || user.role !== 'admin') return <Navigate to="/auctions" />;
  return children;
}

function PageTransition({ children }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.25 }}
    >
      {children}
    </motion.div>
  );
}

function AnimatedRoutes() {
  const location = useLocation();
  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        <Route path="/" element={<Navigate to="/auctions" />} />
        <Route path="/login" element={<PageTransition><Login /></PageTransition>} />
        <Route path="/register" element={<PageTransition><Register /></PageTransition>} />
        <Route path="/auctions" element={<PageTransition><AuctionList /></PageTransition>} />
        <Route path="/auctions/:id" element={<PageTransition><AuctionDetail /></PageTransition>} />
        <Route path="/recommendations" element={<PageTransition><Recommendations /></PageTransition>} />
        <Route path="/live-auctions" element={<PageTransition><LiveAuctions /></PageTransition>} />
        <Route
          path="/watchlist"
          element={<PrivateRoute><PageTransition><Watchlist /></PageTransition></PrivateRoute>}
        />
        <Route
          path="/activity"
          element={<PrivateRoute><PageTransition><MyActivity /></PageTransition></PrivateRoute>}
        />
        <Route
          path="/admin"
          element={
            <PrivateAdminRoute>
              <PageTransition><AdminDashboard /></PageTransition>
            </PrivateAdminRoute>
          }
        />
      </Routes>
    </AnimatePresence>
  );
}

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <SocketProvider>
          <NotificationProvider>
            <BrowserRouter>
              <div className="bg-blobs">
                <div className="blob blob-1" />
                <div className="blob blob-2" />
                <div className="blob blob-3" />
              </div>
              <Toaster position="top-right" />
              <div className="page-shell">
                <Navbar />
                <main className="page-main">
                  <div className="container">
                    <AnimatedRoutes />
                  </div>
                </main>
                <Footer />
              </div>
              <Chatbot />
            </BrowserRouter>
          </NotificationProvider>
        </SocketProvider>
      </AuthProvider>
    </ThemeProvider>
  );
}
