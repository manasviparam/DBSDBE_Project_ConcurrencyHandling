import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import api from '../api/axios';
import AuctionCard from '../components/AuctionCard';

export default function Watchlist() {
  const [items, setItems] = useState(null);

  function load() {
    api.get('/watchlist').then((res) => setItems(res.data));
  }

  useEffect(load, []);

  async function toggleWatch(auctionId) {
    await api.delete(`/watchlist/${auctionId}`);
    setItems((prev) => prev.filter((a) => a.id !== auctionId));
  }

  return (
    <div>
      <div className="section-heading">
        <h2>Your Watchlist</h2>
      </div>
      {!items ? (
        <div className="grid">{Array.from({ length: 3 }).map((_, i) => <div key={i} className="skeleton skeleton-card" />)}</div>
      ) : items.length === 0 ? (
        <div className="empty-state glass">You haven't starred any auctions yet — the heart icon on any card adds it here.</div>
      ) : (
        <motion.div className="grid" layout>
          {items.map((a) => <AuctionCard key={a.id} auction={a} watched onToggleWatch={toggleWatch} />)}
        </motion.div>
      )}
    </div>
  );
}
