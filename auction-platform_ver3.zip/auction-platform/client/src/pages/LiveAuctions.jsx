import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import toast from 'react-hot-toast';
import api from '../api/axios';
import CountdownTimer from '../components/CountdownTimer';
import { IconCalendar, IconMapPin, IconClock, IconNavigation } from '../components/Icons';
import DirectionsModal from '../components/DirectionsModal';
import { useSocket } from '../context/SocketContext';
import { useAuth } from '../context/AuthContext';

function defaultVisitTime(auction) {
  const base = auction.status === 'scheduled' ? new Date(auction.start_time) : new Date();
  if (auction.status === 'active') base.setMinutes(base.getMinutes() + 30);
  const pad = (n) => String(n).padStart(2, '0');
  return `${base.getFullYear()}-${pad(base.getMonth() + 1)}-${pad(base.getDate())}T${pad(base.getHours())}:${pad(base.getMinutes())}`;
}

function VisitRow({ auction, visit, onScheduled, onCancelled, loggedIn }) {
  const [open, setOpen] = useState(false);
  const [time, setTime] = useState(() => visit?.visit_time ? visit.visit_time.slice(0, 16) : defaultVisitTime(auction));
  const [saving, setSaving] = useState(false);
  const [showMap, setShowMap] = useState(false);
  const hasVenue = !!(auction.venue_name || auction.venue_address || (auction.venue_lat != null && auction.venue_lng != null));

  async function confirm() {
    setSaving(true);
    try {
      await api.post(`/visits/${auction.id}`, { visit_time: time });
      toast.success('Visit scheduled!');
      onScheduled();
      setOpen(false);
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to schedule visit');
    } finally {
      setSaving(false);
    }
  }

  async function cancel() {
    await api.delete(`/visits/${auction.id}`);
    toast('Visit cancelled');
    onCancelled();
  }

  return (
    <div className="glass live-row">
      <img src={auction.image_url} alt={auction.product_name} />
      <div className="live-row-body">
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
          <span className={`status status-${auction.status}`}>{auction.status === 'active' ? 'Live now' : 'Upcoming'}</span>
          {auction.category && <span className="category-badge" style={{ position: 'static' }}>{auction.category}</span>}
        </div>
        <Link to={`/auctions/${auction.id}`} className="title-link"><h3 style={{ margin: '4px 0' }}>{auction.product_name}</h3></Link>
        <CountdownTimer startTime={auction.start_time} endTime={auction.end_time} status={auction.status} />
        {auction.venue_name && (
          <div style={{ fontSize: 12, color: 'var(--text-muted)', marginTop: 4, display: 'flex', alignItems: 'center', gap: 4 }}>
            <IconMapPin width={13} height={13} /> {auction.venue_name}
          </div>
        )}
      </div>
      <div className="live-row-action" style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 8 }}>
        <button
          className="secondary"
          onClick={() => setShowMap(true)}
          disabled={!hasVenue}
          title={hasVenue ? 'Show route to the venue' : 'Venue not set yet'}
        >
          <IconNavigation width={14} height={14} /> Directions
        </button>
        {visit ? (
          <div style={{ textAlign: 'right' }}>
            <div style={{ fontSize: 12, color: 'var(--success)', fontWeight: 700, marginBottom: 6 }}>
              <IconCalendar width={13} height={13} /> Visit set: {new Date(visit.visit_time).toLocaleString()}
            </div>
            <button className="ghost" onClick={cancel}>Cancel visit</button>
          </div>
        ) : open ? (
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6, alignItems: 'flex-end' }}>
            <input type="datetime-local" value={time} onChange={(e) => setTime(e.target.value)} />
            <div style={{ display: 'flex', gap: 6 }}>
              <button className="secondary" onClick={() => setOpen(false)}>Cancel</button>
              <button onClick={confirm} disabled={saving}>{saving ? 'Saving...' : 'Confirm'}</button>
            </div>
          </div>
        ) : loggedIn ? (
          <button onClick={() => setOpen(true)}><IconCalendar width={14} height={14} /> Schedule a Visit</button>
        ) : (
          <Link to="/login"><button className="secondary">Log in to schedule</button></Link>
        )}
      </div>
      {showMap && <DirectionsModal auction={auction} onClose={() => setShowMap(false)} />}
    </div>
  );
}

export default function LiveAuctions() {
  const { user } = useAuth();
  const socket = useSocket();
  const [auctions, setAuctions] = useState([]);
  const [visits, setVisits] = useState([]);
  const [loading, setLoading] = useState(true);
  const [failed, setFailed] = useState(false);

  function loadVisits() {
    if (!user) return;
    api.get('/visits').then((res) => setVisits(res.data)).catch(() => {});
  }

  function loadAuctions() {
    api.get('/auctions').then((res) => {
      setAuctions(res.data.filter((a) => (a.status === 'active' || a.status === 'scheduled')
        && a.approval_status !== 'pending' && a.approval_status !== 'rejected'));
      setFailed(false);
      setLoading(false);
    }).catch(() => { setFailed(true); setLoading(false); });
  }

  useEffect(() => {
    loadAuctions();
    loadVisits();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user]);

  // refresh when an auction goes live (12:00 start) or closes
  useEffect(() => {
    socket.on('auction_started', loadAuctions);
    socket.on('auction_closed', loadAuctions);
    return () => { socket.off('auction_started', loadAuctions); socket.off('auction_closed', loadAuctions); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [socket]);

  const visitMap = useMemo(() => new Map(visits.map((v) => [v.auction_id, v])), [visits]);
  const live = auctions.filter((a) => a.status === 'active').sort((a, b) => new Date(a.end_time) - new Date(b.end_time));
  const upcoming = auctions.filter((a) => a.status === 'scheduled').sort((a, b) => new Date(a.start_time) - new Date(b.start_time));

  return (
    <div>
      <div className="section-heading">
        <h2><IconMapPin width={20} height={20} /> Live Auctions</h2>
      </div>
      <p style={{ color: 'var(--text-muted)', marginTop: -8 }}>
        See what's happening right now and what's coming up — schedule a visit and we'll hold your spot.
      </p>

      {user && visits.length > 0 && (
        <div className="admin-section glass" style={{ marginBottom: 24 }}>
          <h3 style={{ marginTop: 0, display: 'flex', alignItems: 'center', gap: 6 }}>
            <IconClock width={16} height={16} /> Your Scheduled Visits
          </h3>
          {visits.map((v) => (
            <div key={v.auction_id} style={{ display: 'flex', justifyContent: 'space-between', padding: '8px 0', borderBottom: '1px solid var(--border)', fontSize: 13 }}>
              <Link to={`/auctions/${v.auction_id}`}>{v.product_name}</Link>
              <span style={{ color: 'var(--text-muted)' }}>{new Date(v.visit_time).toLocaleString()}</span>
            </div>
          ))}
        </div>
      )}

      {loading ? (
        <div className="skeleton skeleton-card" />
      ) : failed && auctions.length === 0 ? (
        <div className="empty-state glass">
          Couldn't load auctions. <button onClick={() => { setLoading(true); loadAuctions(); }}>Retry</button>
        </div>
      ) : (
        <>
          <h3>Happening Now ({live.length})</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12, marginBottom: 28 }}>
            {live.length === 0 && <div className="empty-state glass">No auctions live right now.</div>}
            {live.map((a) => (
              <VisitRow key={a.id} auction={a} visit={visitMap.get(a.id)} onScheduled={loadVisits} onCancelled={loadVisits} loggedIn={!!user} />
            ))}
          </div>

          <h3>Upcoming</h3>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {upcoming.length === 0 && <div className="empty-state glass">Nothing scheduled yet.</div>}
            {upcoming.map((a) => (
              <VisitRow key={a.id} auction={a} visit={visitMap.get(a.id)} onScheduled={loadVisits} onCancelled={loadVisits} loggedIn={!!user} />
            ))}
          </div>
        </>
      )}
    </div>
  );
}
