import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../api/axios';

export default function MyActivity() {
  const [tab, setTab] = useState('bids');
  const [bids, setBids] = useState(null);
  const [won, setWon] = useState(null);

  useEffect(() => {
    api.get('/users/me/bids').then((res) => setBids(res.data));
    api.get('/users/me/won').then((res) => setWon(res.data));
  }, []);

  return (
    <div>
      <div className="section-heading"><h2>My Activity</h2></div>
      <div className="admin-tabs">
        <button className={tab === 'bids' ? 'active' : ''} onClick={() => setTab('bids')}>Bids Placed</button>
        <button className={tab === 'won' ? 'active' : ''} onClick={() => setTab('won')}>Auctions Won</button>
      </div>

      {tab === 'bids' && (
        <div className="data-table-wrap glass">
          <table className="data-table">
            <thead>
              <tr><th>Item</th><th>Your Bid</th><th>Current Highest</th><th>Status</th><th>When</th></tr>
            </thead>
            <tbody>
              {(bids || []).map((b) => (
                <tr key={b.bid_id}>
                  <td><Link to={`/auctions/${b.auction_id}`}>{b.product_name}</Link></td>
                  <td>₹{Number(b.amount).toLocaleString('en-IN')}</td>
                  <td>₹{Number(b.current_highest_bid).toLocaleString('en-IN')}</td>
                  <td><span className={`status status-${b.status}`}>{b.status}</span></td>
                  <td>{new Date(b.created_at).toLocaleString()}</td>
                </tr>
              ))}
              {bids && bids.length === 0 && (
                <tr><td colSpan={5} style={{ textAlign: 'center', color: 'var(--text-muted)' }}>No bids yet — go find something you like!</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}

      {tab === 'won' && (
        <div className="data-table-wrap glass">
          <table className="data-table">
            <thead>
              <tr><th>Item</th><th>Winning Bid</th><th>Won On</th></tr>
            </thead>
            <tbody>
              {(won || []).map((w) => (
                <tr key={w.auction_id}>
                  <td><Link to={`/auctions/${w.auction_id}`}>{w.product_name}</Link></td>
                  <td>₹{Number(w.winning_amount).toLocaleString('en-IN')}</td>
                  <td>{new Date(w.finalized_at).toLocaleString()}</td>
                </tr>
              ))}
              {won && won.length === 0 && (
                <tr><td colSpan={3} style={{ textAlign: 'center', color: 'var(--text-muted)' }}>No wins yet — keep bidding!</td></tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
