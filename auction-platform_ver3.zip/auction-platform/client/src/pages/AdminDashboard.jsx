import { useEffect, useState } from 'react';
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from 'recharts';
import toast from 'react-hot-toast';
import api from '../api/axios';

const CATEGORIES = ['Electronics', 'Art & Antiques', 'Watches & Jewelry', 'Collectibles', 'Fashion', 'Home & Garden'];

function StatCards({ stats }) {
  if (!stats) return null;
  return (
    <div className="stat-cards">
      <div className="stat-card glass"><div className="value">{stats.userCount}</div><div className="label">Users</div></div>
      <div className="stat-card glass"><div className="value">{stats.auctionsByStatus.active}</div><div className="label">Active Auctions</div></div>
      <div className="stat-card glass"><div className="value">{stats.auctionsByStatus.scheduled}</div><div className="label">Scheduled</div></div>
      <div className="stat-card glass"><div className="value">{stats.auctionsByStatus.closed}</div><div className="label">Closed</div></div>
      <div className="stat-card glass"><div className="value">{stats.bidsToday}</div><div className="label">Bids Today</div></div>
      <div className="stat-card glass"><div className="value">₹{Number(stats.activeAuctionsValue).toLocaleString('en-IN')}</div><div className="label">Live Bid Value</div></div>
      <div className="stat-card glass"><div className="value">{stats.pendingApprovals}</div><div className="label">Pending Verification</div></div>
    </div>
  );
}

function OverviewTab() {
  const [stats, setStats] = useState(null);
  useEffect(() => { api.get('/admin/stats').then((res) => setStats(res.data)); }, []);

  // stats.bidsPerDay days come as 'YYYY-MM-DD' strings; parse the components
  // directly instead of `new Date(str)` (which parses as UTC and can shift
  // the weekday label by a day in timezones ahead of UTC).
  const chartData = (stats?.bidsPerDay || []).map((d) => {
    const [y, m, day] = d.day.split('-').map(Number);
    return {
      day: new Date(y, m - 1, day).toLocaleDateString(undefined, { weekday: 'short' }),
      bids: d.count,
    };
  });

  return (
    <div>
      <StatCards stats={stats} />
      <div className="admin-section glass">
        <h3 style={{ marginTop: 0 }}>Bids — last 7 days</h3>
        <div style={{ width: '100%', height: 260 }}>
          <ResponsiveContainer>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--border)" />
              <XAxis dataKey="day" stroke="var(--text-muted)" fontSize={12} />
              <YAxis stroke="var(--text-muted)" fontSize={12} allowDecimals={false} />
              <Tooltip contentStyle={{ background: 'var(--surface-solid)', border: '1px solid var(--border)', borderRadius: 10 }} />
              <Line type="monotone" dataKey="bids" stroke="var(--accent)" strokeWidth={2} dot={{ r: 3, fill: 'var(--accent)' }} activeDot={{ r: 5 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}

function ProductsTab() {
  const [products, setProducts] = useState([]);
  const [form, setForm] = useState({ name: '', description: '', image_url: '', category: CATEGORIES[0], is_certified: false });
  const [editingId, setEditingId] = useState(null);

  function load() { api.get('/products').then((res) => setProducts(res.data)); }
  useEffect(load, []);

  function startEdit(p) {
    setEditingId(p.id);
    setForm({ name: p.name, description: p.description || '', image_url: p.image_url || '', category: p.category || CATEGORIES[0], is_certified: !!p.is_certified });
  }
  function resetForm() {
    setEditingId(null);
    setForm({ name: '', description: '', image_url: '', category: CATEGORIES[0], is_certified: false });
  }

  async function submit(e) {
    e.preventDefault();
    try {
      if (editingId) {
        await api.put(`/products/${editingId}`, form);
        toast.success('Product updated');
      } else {
        await api.post('/products', form);
        toast.success('Product created');
      }
      resetForm();
      load();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to save product');
    }
  }

  async function remove(id) {
    try {
      await api.delete(`/products/${id}`);
      toast.success('Product deleted');
      load();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to delete product');
    }
  }

  return (
    <div>
      <div className="admin-section glass">
        <h3 style={{ marginTop: 0 }}>{editingId ? 'Edit Product' : 'Create Product'}</h3>
        <form onSubmit={submit}>
          <input placeholder="Product name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} required />
          <input placeholder="Description" value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          <input placeholder="Image URL" value={form.image_url} onChange={(e) => setForm({ ...form, image_url: e.target.value })} />
          <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
            {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
          </select>
          <label style={{ fontSize: 13, display: 'flex', alignItems: 'center', gap: 6 }}>
            <input type="checkbox" style={{ width: 'auto' }} checked={form.is_certified} onChange={(e) => setForm({ ...form, is_certified: e.target.checked })} />
            Certified authentic
          </label>
          <button type="submit">{editingId ? 'Save Changes' : 'Add Product'}</button>
          {editingId && <button type="button" className="ghost" onClick={resetForm}>Cancel</button>}
        </form>
      </div>

      <div className="data-table-wrap glass">
        <table className="data-table">
          <thead><tr><th>Name</th><th>Category</th><th>Certified</th><th /></tr></thead>
          <tbody>
            {products.map((p) => (
              <tr key={p.id}>
                <td>{p.name}</td>
                <td>{p.category || '—'}</td>
                <td>{p.is_certified ? '✓' : '—'}</td>
                <td className="row-actions">
                  <button className="secondary" onClick={() => startEdit(p)}>Edit</button>
                  <button className="danger" onClick={() => remove(p.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function toLocalInput(dt) {
  const d = new Date(dt);
  const pad = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
}

function AuctionsTab() {
  const [auctions, setAuctions] = useState([]);
  const [products, setProducts] = useState([]);
  const [form, setForm] = useState({ product_id: '', starting_price: '', start_time: '', end_time: '', is_featured: false });
  const [editingId, setEditingId] = useState(null);

  function load() {
    api.get('/auctions').then((res) => setAuctions(res.data));
    api.get('/products').then((res) => setProducts(res.data));
  }
  useEffect(load, []);

  function startEdit(a) {
    setEditingId(a.id);
    setForm({
      product_id: a.product_id,
      starting_price: a.starting_price,
      start_time: toLocalInput(a.start_time),
      end_time: toLocalInput(a.end_time),
      is_featured: !!a.is_featured,
    });
  }
  function resetForm() {
    setEditingId(null);
    setForm({ product_id: '', starting_price: '', start_time: '', end_time: '', is_featured: false });
  }

  async function submit(e) {
    e.preventDefault();
    try {
      if (editingId) {
        await api.put(`/auctions/${editingId}`, form);
        toast.success('Auction updated');
      } else {
        await api.post('/auctions', form);
        toast.success('Auction created');
      }
      resetForm();
      load();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to save auction');
    }
  }

  async function closeNow(id) {
    try {
      await api.post(`/auctions/${id}/close`);
      toast.success('Auction force-closed');
      load();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to close auction');
    }
  }

  async function remove(id) {
    try {
      await api.delete(`/auctions/${id}`);
      toast.success('Auction deleted');
      load();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to delete auction');
    }
  }

  return (
    <div>
      <div className="admin-section glass">
        <h3 style={{ marginTop: 0 }}>{editingId ? 'Edit Auction' : 'Create Auction'}</h3>
        <form onSubmit={submit}>
          {!editingId && (
            <select value={form.product_id} onChange={(e) => setForm({ ...form, product_id: e.target.value })} required>
              <option value="">Select product</option>
              {products.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          )}
          <input type="number" placeholder="Starting price" value={form.starting_price} onChange={(e) => setForm({ ...form, starting_price: e.target.value })} required />
          <label style={{ fontSize: 13, display: 'flex', alignItems: 'center', gap: 6 }}>Start:
            <input type="datetime-local" value={form.start_time} onChange={(e) => setForm({ ...form, start_time: e.target.value })} required />
          </label>
          <label style={{ fontSize: 13, display: 'flex', alignItems: 'center', gap: 6 }}>End:
            <input type="datetime-local" value={form.end_time} onChange={(e) => setForm({ ...form, end_time: e.target.value })} required />
          </label>
          <label style={{ fontSize: 13, display: 'flex', alignItems: 'center', gap: 6 }}>
            <input type="checkbox" style={{ width: 'auto' }} checked={form.is_featured} onChange={(e) => setForm({ ...form, is_featured: e.target.checked })} />
            Featured
          </label>
          <button type="submit">{editingId ? 'Save Changes' : 'Create Auction'}</button>
          {editingId && <button type="button" className="ghost" onClick={resetForm}>Cancel</button>}
        </form>
      </div>

      <div className="data-table-wrap glass">
        <table className="data-table">
          <thead><tr><th>Item</th><th>Status</th><th>Verification</th><th>Highest Bid</th><th>Ends</th><th /></tr></thead>
          <tbody>
            {auctions.map((a) => (
              <tr key={a.id}>
                <td>{a.product_name}</td>
                <td><span className={`status status-${a.status}`}>{a.status}</span></td>
                <td><span className={`status ${a.approval_status === 'approved' ? 'status-active' : a.approval_status === 'rejected' ? 'status-closed' : 'status-scheduled'}`}>{a.approval_status}</span></td>
                <td>₹{Number(a.current_highest_bid).toLocaleString('en-IN')}</td>
                <td>{new Date(a.end_time).toLocaleString()}</td>
                <td className="row-actions">
                  <button className="secondary" onClick={() => startEdit(a)}>Edit</button>
                  {a.status === 'active' && <button className="ghost" onClick={() => closeNow(a.id)}>Close Now</button>}
                  <button className="danger" onClick={() => remove(a.id)}>Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function ApprovalsTab() {
  const [pending, setPending] = useState(null);

  function load() { api.get('/admin/auctions/pending').then((res) => setPending(res.data)); }
  useEffect(load, []);

  async function decide(id, approval_status) {
    try {
      await api.patch(`/admin/auctions/${id}/approval`, { approval_status });
      toast.success(approval_status === 'approved' ? 'Item authorised for auction' : 'Item rejected');
      load();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to update item');
    }
  }

  if (pending === null) return null;

  return (
    <div>
      <div className="admin-section glass">
        <h3 style={{ marginTop: 0 }}>Verify Items Submitted for Auction</h3>
        <p style={{ marginTop: 0, color: 'var(--text-muted)', fontSize: 13 }}>
          Items listed here were set up for auction but haven't been authorised yet — they stay
          hidden from the public listings until an admin verifies them.
        </p>
      </div>

      {pending.length === 0 ? (
        <div className="empty-state glass">Nothing waiting on verification.</div>
      ) : (
        <div className="data-table-wrap glass">
          <table className="data-table">
            <thead>
              <tr><th>Item</th><th>Category</th><th>Submitted By</th><th>Starting Price</th><th>Certified</th><th /></tr>
            </thead>
            <tbody>
              {pending.map((a) => (
                <tr key={a.id}>
                  <td>{a.product_name}</td>
                  <td>{a.category || '—'}</td>
                  <td>{a.submitted_by || 'Unknown'}</td>
                  <td>₹{Number(a.starting_price).toLocaleString('en-IN')}</td>
                  <td>{a.is_certified ? '✓' : '—'}</td>
                  <td className="row-actions">
                    <button className="secondary" onClick={() => decide(a.id, 'approved')}>Authorise</button>
                    <button className="danger" onClick={() => decide(a.id, 'rejected')}>Reject</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function UsersTab() {
  const [users, setUsers] = useState([]);
  function load() { api.get('/admin/users').then((res) => setUsers(res.data)); }
  useEffect(load, []);

  async function toggleRole(u) {
    const role = u.role === 'admin' ? 'user' : 'admin';
    try {
      await api.patch(`/admin/users/${u.id}/role`, { role });
      toast.success(`${u.name} is now ${role}`);
      load();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to update role');
    }
  }

  async function remove(id) {
    try {
      await api.delete(`/admin/users/${id}`);
      toast.success('User deleted');
      load();
    } catch (err) {
      toast.error(err.response?.data?.error || 'Failed to delete user');
    }
  }

  return (
    <div className="data-table-wrap glass">
      <table className="data-table">
        <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Joined</th><th /></tr></thead>
        <tbody>
          {users.map((u) => (
            <tr key={u.id}>
              <td>{u.name}</td>
              <td>{u.email}</td>
              <td><span className={`status ${u.role === 'admin' ? 'status-active' : 'status-scheduled'}`}>{u.role}</span></td>
              <td>{new Date(u.created_at).toLocaleDateString()}</td>
              <td className="row-actions">
                <button className="secondary" onClick={() => toggleRole(u)}>
                  Make {u.role === 'admin' ? 'User' : 'Admin'}
                </button>
                <button className="danger" onClick={() => remove(u.id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function BidsTab() {
  const [bids, setBids] = useState([]);
  useEffect(() => { api.get('/admin/bids').then((res) => setBids(res.data)); }, []);
  return (
    <div className="data-table-wrap glass">
      <table className="data-table">
        <thead><tr><th>Bidder</th><th>Item</th><th>Amount</th><th>When</th></tr></thead>
        <tbody>
          {bids.map((b) => (
            <tr key={b.id}>
              <td>{b.bidder_name}</td>
              <td>{b.product_name}</td>
              <td>₹{Number(b.amount).toLocaleString('en-IN')}</td>
              <td>{new Date(b.created_at).toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

const TABS = [
  { key: 'overview', label: 'Overview', Component: OverviewTab },
  { key: 'approvals', label: 'Approvals', Component: ApprovalsTab },
  { key: 'products', label: 'Products', Component: ProductsTab },
  { key: 'auctions', label: 'Auctions', Component: AuctionsTab },
  { key: 'users', label: 'Users', Component: UsersTab },
  { key: 'bids', label: 'Bids', Component: BidsTab },
];

export default function AdminDashboard() {
  const [tab, setTab] = useState('overview');
  const Active = TABS.find((t) => t.key === tab).Component;

  return (
    <div>
      <div className="section-heading"><h2>Admin Control Center</h2></div>
      <div className="admin-tabs">
        {TABS.map((t) => (
          <button key={t.key} className={tab === t.key ? 'active' : ''} onClick={() => setTab(t.key)}>{t.label}</button>
        ))}
      </div>
      <Active />
    </div>
  );
}
