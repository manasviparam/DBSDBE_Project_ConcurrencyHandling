import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import api from '../api/axios';
import AuctionCard from '../components/AuctionCard';
import { useAuth } from '../context/AuthContext';

export default function Recommendations() {
  const { user } = useAuth();
  const [items, setItems] = useState(null);
  const [failed, setFailed] = useState(false);
  const [watchedIds, setWatchedIds] = useState(new Set());

  function load() {
    setFailed(false);
    api.get('/recommendations').then((res) => setItems(res.data)).catch(() => setFailed(true));
  }

  useEffect(() => { load(); }, []);

  useEffect(() => {
    if (!user) return;
    api.get('/watchlist').then((res) => setWatchedIds(new Set(res.data.map((a) => a.id)))).catch(() => {});
  }, [user]);

  async function toggleWatch(auctionId) {
    if (watchedIds.has(auctionId)) {
      await api.delete(`/watchlist/${auctionId}`);
      setWatchedIds((prev) => { const next = new Set(prev); next.delete(auctionId); return next; });
    } else {
      await api.post(`/watchlist/${auctionId}`);
      setWatchedIds((prev) => new Set(prev).add(auctionId));
    }
  }

  return (
    <div>
      <div className="section-heading">
        <h2>{user ? 'Recommended for You' : 'Trending Now'}</h2>
      </div>
      <p style={{ color: 'var(--text-muted)', marginTop: -6 }}>
        {user
          ? 'Based on the categories you\'ve bid on and watchlisted.'
          : 'Log in to get picks tailored to your bidding history.'}
      </p>
      {failed && !items ? (
        <div className="empty-state glass">
          Couldn't load recommendations. <button onClick={load}>Retry</button>
        </div>
      ) : !items ? (
        <div className="grid">{Array.from({ length: 4 }).map((_, i) => <div key={i} className="skeleton skeleton-card" />)}</div>
      ) : items.length === 0 ? (
        <div className="empty-state glass">Nothing to recommend right now — check back soon.</div>
      ) : (
        <motion.div className="grid" layout>
          {items.map((a) => <AuctionCard key={a.id} auction={a} watched={watchedIds.has(a.id)} onToggleWatch={toggleWatch} />)}
        </motion.div>
      )}
    </div>
  );
}
