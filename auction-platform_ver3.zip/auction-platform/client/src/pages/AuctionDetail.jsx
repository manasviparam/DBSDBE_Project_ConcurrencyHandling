import { useEffect, useState, useCallback } from 'react';
import { useParams } from 'react-router-dom';
import toast from 'react-hot-toast';
import api from '../api/axios';
import { useSocket } from '../context/SocketContext';
import { useAuth } from '../context/AuthContext';
import BidForm from '../components/BidForm';
import BidHistoryTable from '../components/BidHistoryTable';
import CountdownTimer from '../components/CountdownTimer';
import AuctionCard from '../components/AuctionCard';
import { IconHeart, IconShieldCheck, IconUsers, IconTrophy, IconBell } from '../components/Icons';

export default function AuctionDetail() {
  const { id } = useParams();
  const socket = useSocket();
  const { user } = useAuth();
  const [auction, setAuction] = useState(null);
  const [bids, setBids] = useState([]);
  const [closedInfo, setClosedInfo] = useState(null);
  const [similar, setSimilar] = useState([]);
  const [watched, setWatched] = useState(false);

  const refresh = useCallback(async () => {
    const [auctionRes, bidsRes] = await Promise.all([
      api.get(`/auctions/${id}`),
      api.get(`/auctions/${id}/bids`),
    ]);
    setAuction(auctionRes.data);
    setBids(bidsRes.data);
  }, [id]);

  useEffect(() => {
    refresh();
  }, [refresh]);

  useEffect(() => {
    if (!auction?.category) return;
    api.get(`/recommendations?category=${encodeURIComponent(auction.category)}&exclude=${auction.id}`)
      .then((res) => setSimilar(res.data));
  }, [auction?.category, auction?.id]);

  useEffect(() => {
    if (!user) return;
    api.get('/watchlist').then((res) => setWatched(res.data.some((a) => a.id === Number(id))));
  }, [user, id]);

  async function toggleWatch() {
    if (watched) {
      await api.delete(`/watchlist/${id}`);
      setWatched(false);
    } else {
      await api.post(`/watchlist/${id}`);
      setWatched(true);
    }
  }

  useEffect(() => {
    if (!socket) return;
    socket.emit('join_auction', id);

    function handleBidUpdate(update) {
      if (Number(update.auctionId) !== Number(id)) return;
      setAuction((prev) => prev && { ...prev, current_highest_bid: update.currentHighestBid });
      if (update.bidderId !== user?.id) toast(`New bid: ₹${update.currentHighestBid} by ${update.bidderName}`, { icon: <IconBell width={16} height={16} /> });
      refresh(); // re-pull bid history for the table
    }

    function handleAuctionClosed(info) {
      if (Number(info.auctionId) !== Number(id)) return;
      setClosedInfo(info);
      setAuction((prev) => prev && { ...prev, status: 'closed' });
    }

    socket.on('bid_update', handleBidUpdate);
    socket.on('auction_closed', handleAuctionClosed);

    return () => {
      socket.emit('leave_auction', id);
      socket.off('bid_update', handleBidUpdate);
      socket.off('auction_closed', handleAuctionClosed);
    };
  }, [socket, id, refresh, user?.id]);

  if (!auction) return <div className="skeleton skeleton-card" style={{ marginTop: 20 }} />;

  return (
    <div>
      <div className="detail-hero glass">
        <img src={auction.image_url || 'https://picsum.photos/seed/fallback/700/500'} alt={auction.product_name} />
        <div className="detail-meta">
          <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
            {auction.category && <span className="category-badge" style={{ position: 'static' }}>{auction.category}</span>}
            {auction.is_certified ? (
              <span className="category-badge certified-badge" style={{ position: 'static' }}>
                <IconShieldCheck width={12} height={12} /> Certified Authentic
              </span>
            ) : null}
          </div>
          <h2 style={{ margin: 0 }}>{auction.product_name}</h2>
          <p style={{ color: 'var(--text-muted)', margin: 0 }}>{auction.product_description}</p>
          <p className="current-bid">₹{Number(auction.current_highest_bid).toLocaleString('en-IN')}</p>
          <div style={{ display: 'flex', gap: 10, alignItems: 'center', flexWrap: 'wrap' }}>
            <span className={`status status-${auction.status}`}>{auction.status}</span>
            <CountdownTimer startTime={auction.start_time} endTime={auction.end_time} status={auction.status} />
            <span className="bidder-count"><IconUsers width={13} height={13} /> {auction.bidder_count || 0} bidder{Number(auction.bidder_count) === 1 ? '' : 's'}</span>
            {user && (
              <button className="secondary" onClick={toggleWatch}>
                <IconHeart width={14} height={14} filled={watched} /> {watched ? 'Watching' : 'Watch'}
              </button>
            )}
          </div>

          {closedInfo && (
            <div className="alert" style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <IconTrophy width={18} height={18} /> Auction closed. Winner: user #{closedInfo.winnerId} at ₹{closedInfo.winningBid}
            </div>
          )}

          <BidForm auction={auction} onBidPlaced={refresh} />
        </div>
      </div>

      <h3>Bid History</h3>
      <BidHistoryTable bids={bids} />

      {similar.length > 0 && (
        <>
          <div className="section-heading">
            <h2>You might also like</h2>
          </div>
          <div className="grid">
            {similar.map((a) => <AuctionCard key={a.id} auction={a} />)}
          </div>
        </>
      )}
    </div>
  );
}
