import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { motion } from 'framer-motion';
import api from '../api/axios';
import AuctionCard from '../components/AuctionCard';
import CategoryTiles from '../components/CategoryTiles';
import FeaturedCarousel from '../components/FeaturedCarousel';
import StatsTicker from '../components/StatsTicker';
import { useAuth } from '../context/AuthContext';
import { useSocket } from '../context/SocketContext';
import { IconStar, IconShieldCheck } from '../components/Icons';

export default function AuctionList() {
  const { user } = useAuth();
  const socket = useSocket();
  const [auctions, setAuctions] = useState([]);
  const [categories, setCategories] = useState([]);
  const [watchedIds, setWatchedIds] = useState(new Set());
  const [loading, setLoading] = useState(true);
  const [searchParams, setSearchParams] = useSearchParams();

  const search = searchParams.get('search') || '';
  const category = searchParams.get('category') || '';
  const status = searchParams.get('status') || 'active';
  const sort = searchParams.get('sort') || 'ending';
  const minPrice = searchParams.get('min') || '';
  const maxPrice = searchParams.get('max') || '';
  const featuredOnly = searchParams.get('featured') === '1';
  const certifiedOnly = searchParams.get('certified') === '1';

  useEffect(() => {
    api.get('/auctions').then((res) => {
      setAuctions(res.data);
      setLoading(false);
    });
    api.get('/products/categories').then((res) => setCategories(res.data));
  }, []);

  // Keep every card's bid value live, not just the one auction you're viewing.
  useEffect(() => {
    if (!socket) return;
    function handleBidUpdate(update) {
      setAuctions((prev) => prev.map((a) => (
        a.id === update.auctionId
          ? { ...a, current_highest_bid: update.currentHighestBid, bid_count: (a.bid_count || 0) + 1 }
          : a
      )));
    }
    function handleAuctionClosed(info) {
      setAuctions((prev) => prev.map((a) => (a.id === info.auctionId ? { ...a, status: 'closed' } : a)));
    }
    socket.on('bid_update', handleBidUpdate);
    socket.on('auction_closed', handleAuctionClosed);
    return () => {
      socket.off('bid_update', handleBidUpdate);
      socket.off('auction_closed', handleAuctionClosed);
    };
  }, [socket]);

  useEffect(() => {
    if (!user) { setWatchedIds(new Set()); return; }
    api.get('/watchlist').then((res) => setWatchedIds(new Set(res.data.map((a) => a.id))));
  }, [user]);

  async function toggleWatch(auctionId) {
    if (watchedIds.has(auctionId)) {
      await api.delete(`/watchlist/${auctionId}`);
      setWatchedIds((prev) => { const next = new Set(prev); next.delete(auctionId); return next; });
    } else {
      await api.post(`/watchlist/${auctionId}`);
      setWatchedIds((prev) => new Set(prev).add(auctionId));
    }
  }

  function updateParam(key, value) {
    const next = new URLSearchParams(searchParams);
    if (value) next.set(key, value); else next.delete(key);
    setSearchParams(next);
  }

  const featured = useMemo(
    () => auctions.filter((a) => a.is_featured && a.status === 'active' && a.approval_status !== 'pending' && a.approval_status !== 'rejected'),
    [auctions]
  );

  const filtered = useMemo(() => {
    let list = auctions.filter((a) => {
      if (a.approval_status === 'pending' || a.approval_status === 'rejected') return false;
      if (status !== 'all' && a.status !== status) return false;
      if (category && a.category !== category) return false;
      if (search && !`${a.product_name} ${a.product_description}`.toLowerCase().includes(search.toLowerCase())) return false;
      if (minPrice && Number(a.current_highest_bid) < Number(minPrice)) return false;
      if (maxPrice && Number(a.current_highest_bid) > Number(maxPrice)) return false;
      if (featuredOnly && !a.is_featured) return false;
      if (certifiedOnly && !a.is_certified) return false;
      return true;
    });
    if (sort === 'ending') list = [...list].sort((a, b) => new Date(a.end_time) - new Date(b.end_time));
    if (sort === 'price_high') list = [...list].sort((a, b) => b.current_highest_bid - a.current_highest_bid);
    if (sort === 'price_low') list = [...list].sort((a, b) => a.current_highest_bid - b.current_highest_bid);
    if (sort === 'most_bids') list = [...list].sort((a, b) => (b.bid_count || 0) - (a.bid_count || 0));
    return list;
  }, [auctions, status, category, search, sort, minPrice, maxPrice, featuredOnly, certifiedOnly]);

  return (
    <div>
      <div className="hero">
        <h1>Bid. Win. Repeat.</h1>
        <p>Live auctions across electronics, art, watches, fashion and more — updated in real time.</p>
        <StatsTicker />
      </div>

      {!loading && featured.length > 0 && <FeaturedCarousel auctions={featured} />}

      <CategoryTiles categories={categories} active={category} onSelect={(c) => updateParam('category', c)} />

      <div className="toolbar glass">
        <input
          type="text"
          placeholder="Search..."
          value={search}
          onChange={(e) => updateParam('search', e.target.value)}
        />
        <select value={status} onChange={(e) => updateParam('status', e.target.value)}>
          <option value="active">Active</option>
          <option value="scheduled">Scheduled</option>
          <option value="closed">Closed</option>
          <option value="all">All statuses</option>
        </select>
        <input
          type="number"
          placeholder="Min ₹"
          value={minPrice}
          onChange={(e) => updateParam('min', e.target.value)}
          style={{ width: 90 }}
        />
        <input
          type="number"
          placeholder="Max ₹"
          value={maxPrice}
          onChange={(e) => updateParam('max', e.target.value)}
          style={{ width: 90 }}
        />
        <select value={sort} onChange={(e) => updateParam('sort', e.target.value)}>
          <option value="ending">Ending soon</option>
          <option value="price_high">Price: high to low</option>
          <option value="price_low">Price: low to high</option>
          <option value="most_bids">Most bids</option>
        </select>
        <button
          type="button"
          className={`chip-btn${featuredOnly ? ' active' : ''}`}
          onClick={() => updateParam('featured', featuredOnly ? '' : '1')}
        >
          <IconStar width={13} height={13} filled={featuredOnly} /> Featured
        </button>
        <button
          type="button"
          className={`chip-btn${certifiedOnly ? ' active' : ''}`}
          onClick={() => updateParam('certified', certifiedOnly ? '' : '1')}
        >
          <IconShieldCheck width={13} height={13} /> Certified
        </button>
        <div className="spacer" />
        <span style={{ fontSize: 13, color: 'var(--text-muted)' }}>{filtered.length} auctions</span>
      </div>

      <div className="section-heading">
        <h2>{category || 'All'} Auctions</h2>
      </div>

      {loading ? (
        <div className="grid">
          {Array.from({ length: 6 }).map((_, i) => <div key={i} className="skeleton skeleton-card" />)}
        </div>
      ) : filtered.length === 0 ? (
        <div className="empty-state glass">No auctions match your filters.</div>
      ) : (
        <motion.div className="grid" layout>
          {filtered.map((a) => (
            <AuctionCard key={a.id} auction={a} watched={watchedIds.has(a.id)} onToggleWatch={toggleWatch} />
          ))}
        </motion.div>
      )}
    </div>
  );
}
