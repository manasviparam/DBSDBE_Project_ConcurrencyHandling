import { createContext, useContext, useEffect } from 'react';
import { io } from 'socket.io-client';
import { useAuth } from './AuthContext';

const SOCKET_URL = import.meta.env.VITE_SOCKET_URL || 'http://localhost:5000';

// A single socket for the app's entire lifetime, created once at module scope
// rather than per-component. Creating it inside a component (even guarded by
// a ref) is fragile under React 18 StrictMode: the mount/cleanup/mount replay
// of effects in dev can call .disconnect() on it, and an explicit disconnect
// does not auto-reconnect — every listener registered after that point would
// silently never fire.
const socket = io(SOCKET_URL, { autoConnect: true });

const SocketContext = createContext(socket);

export function SocketProvider({ children }) {
  const { user } = useAuth();

  useEffect(() => {
    if (!user) return;
    function sendIdentify() {
      socket.emit('identify', user.id);
    }
    sendIdentify();
    socket.on('connect', sendIdentify);
    return () => socket.off('connect', sendIdentify);
  }, [user]);

  return (
    <SocketContext.Provider value={socket}>
      {children}
    </SocketContext.Provider>
  );
}

export function useSocket() {
  return useContext(SocketContext);
}
