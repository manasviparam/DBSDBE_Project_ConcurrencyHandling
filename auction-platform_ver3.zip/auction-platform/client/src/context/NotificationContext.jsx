import { createContext, useContext, useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { useSocket } from './SocketContext';
import { useAuth } from './AuthContext';
import { IconBell } from '../components/Icons';

const NotificationContext = createContext(null);

export function NotificationProvider({ children }) {
  const socket = useSocket();
  const { user } = useAuth();
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    if (!socket || !user) return;

    function handleOutbid(payload) {
      const entry = {
        id: `${payload.auctionId}-${Date.now()}`,
        auctionId: payload.auctionId,
        message: `You've been outbid on "${payload.productName}" — new bid ₹${payload.newAmount} by ${payload.outbidBy}.`,
        time: new Date().toISOString(),
        read: false,
      };
      setNotifications((prev) => [entry, ...prev].slice(0, 20));
      toast(entry.message, { icon: <IconBell width={16} height={16} /> });
    }

    socket.on('outbid', handleOutbid);
    return () => socket.off('outbid', handleOutbid);
  }, [socket, user]);

  function markAllRead() {
    setNotifications((prev) => prev.map((n) => ({ ...n, read: true })));
  }

  const unreadCount = notifications.filter((n) => !n.read).length;

  return (
    <NotificationContext.Provider value={{ notifications, unreadCount, markAllRead }}>
      {children}
    </NotificationContext.Provider>
  );
}

export function useNotifications() {
  return useContext(NotificationContext);
}
