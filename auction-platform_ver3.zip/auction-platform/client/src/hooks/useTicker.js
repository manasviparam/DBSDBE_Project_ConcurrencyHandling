import { useEffect, useState } from 'react';

// A single shared setInterval powering every countdown on the page, instead
// of each widget running its own timer. Cards subscribe/unsubscribe and all
// their updates land in the same tick, so React batches them into one render
// pass instead of dozens of independent ones.
const listeners = new Set();
let intervalId = null;

function ensureStarted() {
  if (intervalId) return;
  intervalId = setInterval(() => listeners.forEach((cb) => cb()), 1000);
}

export function useTicker() {
  const [, setTick] = useState(0);
  useEffect(() => {
    ensureStarted();
    const cb = () => setTick((t) => t + 1);
    listeners.add(cb);
    return () => {
      listeners.delete(cb);
      if (listeners.size === 0 && intervalId) {
        clearInterval(intervalId);
        intervalId = null;
      }
    };
  }, []);
}
